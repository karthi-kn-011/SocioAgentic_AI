import pytest
import uuid
from backend.app.graph.workflow import social_graph
from backend.app.graph.state import SocialAgentState

@pytest.mark.asyncio
async def test_langgraph_workflow_execution():
    thread_id = str(uuid.uuid4())
    state: SocialAgentState = {
        "topic": "Autonomous LangGraph Social Media Orchestration",
        "tone": "Visionary & Thought Leadership",
        "platforms": ["TWITTER", "LINKEDIN"],
        "iteration_count": 0,
        "thread_id": thread_id
    }

    config = {"configurable": {"thread_id": thread_id}}
    final_state = await social_graph.ainvoke(state, config=config)

    assert "variants" in final_state
    assert "TWITTER" in final_state["variants"]
    assert "LINKEDIN" in final_state["variants"]
    assert final_state["review_score"] > 0
    assert final_state["status"] == "AWAITING_HUMAN_APPROVAL"
    assert "post_id" in final_state
