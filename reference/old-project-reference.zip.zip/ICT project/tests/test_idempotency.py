import pytest
from backend.app.services.publishing_service import publishing_service
from backend.app.database import crud, models

@pytest.mark.asyncio
async def test_publishing_idempotency_prevents_duplicate_publish(db_session):
    # 1. Create and approve test post
    post = crud.create_post(
        db_session,
        topic="Idempotency Test Post",
        target_platforms=["TWITTER"],
        platform_contents={"TWITTER": "Idempotent Tweet #Security"},
        status=models.PostStatus.APPROVED
    )

    # 2. First publish invocation
    first_res = await publishing_service.publish_post_now(post.id)
    assert first_res["success"] is True
    assert first_res["status"] == "PUBLISHED"

    # Count publish logs
    db_session.expire_all()
    logs_first = db_session.query(models.PublishLog).filter(models.PublishLog.post_id == post.id).all()
    assert len(logs_first) == 1

    # 3. Second publish invocation on the SAME post
    second_res = await publishing_service.publish_post_now(post.id)
    assert second_res["success"] is True
    assert second_res["status"] == "PUBLISHED"
    assert "already been successfully published" in second_res.get("message", "")

    # Count publish logs must still be 1 (no duplicates created)
    db_session.expire_all()
    logs_second = db_session.query(models.PublishLog).filter(models.PublishLog.post_id == post.id).all()
    assert len(logs_second) == 1
