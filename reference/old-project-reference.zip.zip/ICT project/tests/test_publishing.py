import pytest
from datetime import datetime, timedelta
from backend.app.services.publishing_service import publishing_service
from backend.app.database import crud, models
from backend.app.auth.security import token_security

@pytest.mark.asyncio
async def test_publishing_service_all_platforms_with_db_accounts(db_session):
    # Setup active social accounts with encrypted tokens
    crud.upsert_social_account(
        db_session,
        platform=models.PlatformType.TWITTER,
        account_name="@BrandX",
        encrypted_access_token=token_security.encrypt("token_x_123")
    )
    crud.upsert_social_account(
        db_session,
        platform=models.PlatformType.LINKEDIN,
        account_name="Brand LinkedIn",
        account_id="urn:li:organization:998877",
        encrypted_access_token=token_security.encrypt("token_li_123")
    )
    crud.upsert_social_account(
        db_session,
        platform=models.PlatformType.META_FACEBOOK,
        account_name="Brand Facebook Page",
        account_id="page_123456",
        encrypted_access_token=token_security.encrypt("token_fb_123")
    )
    crud.upsert_social_account(
        db_session,
        platform=models.PlatformType.META_INSTAGRAM,
        account_name="Instagram @Brand",
        account_id="ig_123456",
        encrypted_access_token=token_security.encrypt("token_ig_123")
    )

    # Create test post with 4 platform variants
    post = crud.create_post(
        db_session,
        topic="Multi-Platform 4-Channel Launch",
        target_platforms=["TWITTER", "LINKEDIN", "META_FACEBOOK", "META_INSTAGRAM"],
        platform_contents={
            "TWITTER": "Tweet variant #Launch",
            "LINKEDIN": "LinkedIn professional variant",
            "META_FACEBOOK": "Facebook community variant",
            "META_INSTAGRAM": "Instagram visual story variant"
        },
        status=models.PostStatus.APPROVED
    )

    result = await publishing_service.publish_post_now(post.id)
    assert result["success"] is True
    assert result["status"] == "PUBLISHED"
    assert len(result["platform_results"]) == 4

    # Check database record
    db_session.expire_all()
    updated_post = crud.get_post_by_id(db_session, post.id)
    assert updated_post.status == models.PostStatus.PUBLISHED
    assert len(updated_post.publish_logs) == 4

def test_token_security_encryption():
    secret_token = "xoxb-9876543210-secure-slack-or-oauth-key"
    encrypted = token_security.encrypt(secret_token)
    assert encrypted != secret_token
    
    decrypted = token_security.decrypt(encrypted)
    assert decrypted == secret_token

def test_rest_api_posts_endpoints(client):
    # Generate API
    resp = client.post("/api/posts/generate", json={
        "topic": "FastAPI REST API Integration Test",
        "tone": "Casual & Conversational",
        "platforms": ["TWITTER"]
    })
    assert resp.status_code == 201
    data = resp.json()
    assert data["success"] is True
    assert "post_id" in data["data"]
    
    # List API
    list_resp = client.get("/api/posts")
    assert list_resp.status_code == 200
    posts_data = list_resp.json()
    assert posts_data["count"] >= 1

    # Stats API
    stats_resp = client.get("/api/stats")
    assert stats_resp.status_code == 200
    stats = stats_resp.json()
    assert stats["total_generated"] >= 1

    # Analytics API
    analytics_resp = client.get("/api/analytics")
    assert analytics_resp.status_code == 200
    analytics = analytics_resp.json()
    assert "summary" in analytics
    assert "platform_performance" in analytics
    assert "live_engagement" in analytics

    # Image generation API
    img_resp = client.post("/api/images/generate", json={"topic": "AI Marketing"})
    assert img_resp.status_code == 200
    img_data = img_resp.json()
    assert img_data["success"] is True
    assert "image_url" in img_data

