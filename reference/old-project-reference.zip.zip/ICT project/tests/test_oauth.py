import pytest
from backend.app.auth.oauth import oauth_manager
from backend.app.auth.security import token_security
from backend.app.database import crud, models

def test_pkce_generation():
    verifier, challenge = oauth_manager.generate_pkce()
    assert len(verifier) >= 43
    assert len(challenge) > 0
    assert verifier != challenge

def test_oauth_state_generation_and_consumption():
    state = oauth_manager.create_oauth_state(
        platform="TWITTER",
        redirect_uri="http://localhost:8000/callback",
        code_verifier="test_verifier_123"
    )
    assert len(state) > 16

    # Valid consumption
    data = oauth_manager.validate_and_consume_state(state, "TWITTER")
    assert data["platform"] == "TWITTER"
    assert data["code_verifier"] == "test_verifier_123"

    # Consuming again must raise ValueError (one-time use)
    with pytest.raises(ValueError):
        oauth_manager.validate_and_consume_state(state, "TWITTER")

@pytest.mark.asyncio
async def test_oauth_code_exchange_mock_mode():
    result = await oauth_manager.exchange_code(
        platform="TWITTER",
        code="mock_auth_code_12345"
    )
    assert result["success"] is True
    assert result["platform"] == "TWITTER"
    assert "encrypted_access_token" in result
    
    # Decrypt token
    plain = token_security.decrypt(result["encrypted_access_token"])
    assert plain.startswith("mock_twitter_token_")

def test_oauth_endpoints(client, db_session):
    # 1. URL generation endpoint
    url_resp = client.get("/api/accounts/oauth/url?platform=TWITTER")
    assert url_resp.status_code == 200
    data = url_resp.json()
    assert "oauth_url" in data
    assert "twitter.com" in data["oauth_url"]
    assert "code_challenge=" in data["oauth_url"]

    # 2. Callback endpoint
    state = oauth_manager.create_oauth_state("TWITTER", "http://localhost:8000/api/accounts/oauth/callback")
    cb_resp = client.get(f"/api/accounts/oauth/callback?code=mock_code_abc&state={state}&platform=TWITTER")
    assert cb_resp.status_code == 200
    cb_data = cb_resp.json()
    assert cb_data["success"] is True
    assert "account" in cb_data

    # Check database account
    account = crud.get_social_account_by_platform(db_session, models.PlatformType.TWITTER)
    assert account is not None
    assert account.encrypted_access_token is not None
