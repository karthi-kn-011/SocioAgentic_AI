import pytest
from backend.app.agents.content_agent import ContentGenerationAgent
from backend.app.agents.review_agent import ContentReviewAgent
from backend.app.agents.scheduler_agent import SchedulerOptimizationAgent

@pytest.mark.asyncio
async def test_content_generation_mock():
    agent = ContentGenerationAgent(provider="mock")
    topic = "Next-Gen AI Agents in Production"
    variants = await agent.generate_variants(
        topic=topic,
        tone="Professional & Engaging",
        platforms=["TWITTER", "LINKEDIN", "META_FACEBOOK"]
    )
    
    assert "TWITTER" in variants
    assert "LINKEDIN" in variants
    assert "META_FACEBOOK" in variants
    assert len(variants["TWITTER"]) <= 280
    assert "Next-gen" in variants["TWITTER"] or "AI" in variants["TWITTER"]

def test_content_review_agent_pass():
    review_agent = ContentReviewAgent()
    variants = {
        "TWITTER": "🚀 Transforming workflows with AI Agents today! #AI #Innovation",
        "LINKEDIN": "Modern enterprise automation is evolving.\n\nHere are 3 key lessons:\n1. Keep humans in the loop\n2. Iterate quickly\n\n#Tech #Strategy"
    }
    result = review_agent.review_variants(variants, "AI Automation")
    assert result["score"] >= 70
    assert result["passed"] is True

def test_content_review_agent_flag_banned_word():
    review_agent = ContentReviewAgent()
    variants = {
        "TWITTER": "Guaranteed profit fast with free crypto scam! Click here."
    }
    result = review_agent.review_variants(variants, "Investment")
    assert result["passed"] is False
    assert any("policy violation" in iss for iss in result["issues"])

def test_scheduler_optimization_agent():
    sched_agent = SchedulerOptimizationAgent()
    result = sched_agent.recommend_optimal_slot(["TWITTER", "LINKEDIN"])
    assert "recommended_time" in result
    assert result["target_hour"] in [9, 12, 17, 8, 10, 14]
