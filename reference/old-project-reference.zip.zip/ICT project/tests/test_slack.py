import pytest
from backend.app.integrations.slack import slack_notifier
from backend.app.database.database import SessionLocal
from backend.app.database import crud, models

@pytest.mark.asyncio
async def test_slack_block_kit_generation():
    res = await slack_notifier.send_approval_request(
        post_id=99,
        topic="Test Slack HITL Integration",
        variants={"TWITTER": "Test tweet content #Testing"},
        review_score=95,
        feedback="Looks solid!"
    )
    assert res["ok"] is True
    assert "blocks" in res
    assert len(res["blocks"]) >= 4

def test_slack_interactive_webhook_action(client, db_session):
    # Create test post
    post = crud.create_post(db_session, topic="Webhook Test Post", raw_content="Test text")
    
    # Send mock Slack action payload
    payload = {
        "type": "block_actions",
        "user": {"username": "test_approver"},
        "actions": [
            {
                "action_id": "approve_schedule_post",
                "value": str(post.id)
            }
        ]
    }
    
    resp = client.post("/api/slack/actions", json=payload)
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "handled"

    # Verify DB post status changed
    db_session.expire_all()
    updated_post = crud.get_post_by_id(db_session, post.id)
    assert updated_post.status == models.PostStatus.SCHEDULED

def test_slack_signature_verification_logic():
    import time
    import hmac
    import hashlib
    from backend.app.config import settings
    
    body = b'{"payload":"test"}'
    ts = str(int(time.time()))
    secret = "test-slack-signing-secret"
    
    # Test valid signature calculation
    sig_basestring = f"v0:{ts}:".encode("utf-8") + body
    valid_sig = "v0=" + hmac.new(secret.encode("utf-8"), sig_basestring, hashlib.sha256).hexdigest()
    
    # Temporarily set secret and mock_mode = False for verification test
    orig_secret = settings.SLACK_SIGNING_SECRET
    orig_mock = slack_notifier.mock_mode
    try:
        settings.SLACK_SIGNING_SECRET = secret
        slack_notifier.mock_mode = False

        # 1. Valid signature -> True
        assert slack_notifier.verify_slack_signature(body, ts, valid_sig) is True

        # 2. Tampered signature -> False
        assert slack_notifier.verify_slack_signature(body, ts, "v0=tampered_signature_hex") is False

        # 3. Expired timestamp (> 5 minutes ago) -> False
        old_ts = str(int(time.time()) - 600)
        assert slack_notifier.verify_slack_signature(body, old_ts, valid_sig) is False

        # 4. Missing headers -> False
        assert slack_notifier.verify_slack_signature(body, None, None) is False
    finally:
        settings.SLACK_SIGNING_SECRET = orig_secret
        slack_notifier.mock_mode = orig_mock

