import httpx

def test_live_end_to_end_flow(client):
    # 1. Check frontend assets
    r_html = client.get("/")
    assert r_html.status_code == 200
    assert "SocialAgent AI" in r_html.text

    r_css = client.get("/static/css/styles.css")
    assert r_css.status_code == 200

    r_js = client.get("/static/js/app.js")
    assert r_js.status_code == 200
    print(" Frontend Static Assets Validated: HTML, CSS, JS 200 OK")

    # 2. Trigger Post Generation
    r_gen = client.post("/api/posts/generate", json={
        "topic": "Next-Gen AI Agents in Production",
        "tone": "Visionary & Thought Leadership",
        "platforms": ["TWITTER", "LINKEDIN", "META_FACEBOOK"]
    })
    assert r_gen.status_code in (200, 201)
    gen_data = r_gen.json()
    post_id = gen_data["data"]["post_id"]
    print(f" LangGraph Multi-Agent Pipeline Succeeded: Generated Post #{post_id}")
    print(f"   AI Quality Score: {gen_data['data']['review_score']}/100")
    print(f"   Status: {gen_data['data']['status']}")

    # 3. Check Slack Queue
    r_slack = client.get("/api/slack/messages")
    assert r_slack.status_code == 200
    slack_msgs = r_slack.json()["messages"]
    assert len(slack_msgs) > 0
    print(f" Slack Interactive Block Kit Dispatched: Found {len(slack_msgs)} approval card(s)")

    # 4. Simulate Slack Button Approval
    r_action = client.post("/api/slack/actions", json={
        "type": "block_actions",
        "user": {"username": "lead_editor"},
        "actions": [{"action_id": "approve_schedule_post", "value": str(post_id)}]
    })
    assert r_action.status_code == 200
    print(f" Slack Interactive Approval Received: Post #{post_id} Approved & Scheduled")

    # 5. Check Posts list and Stats
    r_posts = client.get("/api/posts")
    posts = r_posts.json()["posts"]
    matching = [p for p in posts if p["id"] == post_id][0]
    print(f" Post Database State: Status={matching['status']}, Scheduled Time={matching['scheduled_time']}")

    r_stats = client.get("/api/stats")
    stats = r_stats.json()
    print(" Dashboard Stats:", stats)
    assert stats["total_generated"] >= 1

if __name__ == "__main__":
    test_live_end_to_end_flow()
