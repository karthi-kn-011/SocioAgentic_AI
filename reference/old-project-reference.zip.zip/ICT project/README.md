# AI Social Media Agent 🚀

An autonomous, multi-agent social media management platform built with **LangGraph**, **FastAPI**, **Slack Human-in-the-Loop (HITL)** interactive approval, **APScheduler**, and multi-platform connectors (**X / Twitter**, **LinkedIn**, **Facebook Page**, and **Instagram Graph API**) with a glassmorphic web dashboard, database migrations, persistent checkpointing, and PKCE-secured OAuth 2.0.

---

## 🌟 Architecture & System Overview

```
User enters topic ➔ LangGraph Agent Pipeline ➔ AI Review & Scoring
                                                    │
                                                    ▼
                                           Human-in-the-Loop (Slack)
                                      (HMAC-SHA256 Signature Verified)
                                           ┌─────────┴─────────┐
                                       [Approve]            [Reject]
                                           │                   │
                                           ▼                   ▼
                                      APScheduler        Self-Correction
                                           │
                                           ▼
                                 Multi-Platform APIs
                         (X API v2 / LinkedIn / Meta Graph)
                         (Decrypted OAuth Token Dispatched)
                                           │
                                           ▼
                               Published & Audited (PublishLog)
```

### Core Components

1. **Multi-Agent LangGraph Workflow**:
   - `ContentGenerationAgent`: Multi-platform copywriting with persona/tone selection (Mock, OpenAI, Anthropic, Gemini).
   - `ContentReviewAgent`: Automated policy, brand safety, character limit, and virality scoring with an automated feedback loop.
   - `SchedulerOptimizationAgent`: Audience peak engagement slot recommendation.
   - **Persistent Checkpointing**: Workflow states and threads survive application restarts using persistent checkpointer (`SqliteCheckpointSaver`).
2. **Slack HITL Approval Engine**:
   - Interactive Slack Block Kit action cards (`[Approve & Schedule]`, `[Publish Now]`, `[Reject / Redo]`).
   - Request signature verification with `SLACK_SIGNING_SECRET` (HMAC-SHA256).
   - Timestamp-based anti-replay verification (5-minute expiration).
   - Action trigger deduplication preventing duplicate execution.
   - Interactive dashboard emulator for offline/sandbox testing.
3. **Multi-Platform OAuth 2.0 Engine**:
   - **X (Twitter)**: OAuth 2.0 with PKCE (`code_verifier` & `code_challenge` S256), scope management, state validation, and token refresh.
   - **LinkedIn**: OAuth 2.0 authorization code flow with user/organization resolution.
   - **Meta (Facebook & Instagram)**: Long-lived Page Access Token exchange and linked Instagram Business Account detection.
   - Cryptographically random state values stored with TTL expiration.
4. **Token Encryption at Rest**:
   - Symmetric AES-256 (Fernet) encryption for all OAuth access and refresh tokens.
   - Tokens decrypted in-memory only when dispatching API calls.
   - API endpoints and logs never leak raw secrets.
5. **Publishing Idempotency & Concurrency Safety**:
   - Atomic post state transitions (`PostStatus.PUBLISHING`).
   - Duplicate publish prevention and deduplicated `PublishLog` records.
6. **Database Migrations (Alembic)**:
   - Full Alembic migration environment supporting both SQLite and PostgreSQL.
7. **Production Docker Configuration**:
   - Multi-container setup with PostgreSQL service, health checks, volume persistence, and startup migration automation.

---

## 🛠️ Getting Started

### 1. Prerequisites
- Python 3.10+ (Tested on Python 3.11, 3.12, 3.13)
- Git

### 2. Installation

Clone the repository and install requirements:
```powershell
pip install -r requirements.txt
```

### 3. Environment Configuration

Copy the sample environment file:
```powershell
cp .env.example .env
```

Key environment variables:
| Variable | Description | Default |
| :--- | :--- | :--- |
| `ENVIRONMENT` | `development` or `production` | `development` |
| `DATABASE_URL` | Database connection string | `sqlite:///./social_agent.db` |
| `SECRET_KEY` | Application secret key (min 32 chars in production) | Dev key |
| `FERNET_KEY` | Symmetric token encryption key | Dev key |
| `SLACK_SIGNING_SECRET` | Slack app signing secret | Empty (Mock mode) |
| `SLACK_BOT_TOKEN` | Slack Bot OAuth Token (`xoxb-...`) | Empty (Mock mode) |
| `SLACK_MOCK_MODE` | Enable in-dashboard Slack simulator | `true` |
| `MOCK_SOCIAL_PUBLISHING` | Simulate platform publishing | `true` |
| `X_CLIENT_ID` / `X_CLIENT_SECRET` | X (Twitter) OAuth 2.0 credentials | Empty |
| `LINKEDIN_CLIENT_ID` / `LINKEDIN_CLIENT_SECRET` | LinkedIn OAuth 2.0 credentials | Empty |
| `META_APP_ID` / `META_APP_SECRET` | Meta Developer app credentials | Empty |

### 4. Database Migrations

Apply database schema migrations:
```powershell
python -m alembic upgrade head
```

### 5. Run the Application

Start the FastAPI server:
```powershell
python run.py
```

Access the application:
- 🌐 **Web Dashboard**: [http://localhost:8000](http://localhost:8000)
- 📖 **Interactive Swagger Docs**: [http://localhost:8000/docs](http://localhost:8000/docs)
- 📊 **Health Check**: [http://localhost:8000/api/health](http://localhost:8000/api/health)
- 📈 **Analytics Endpoint**: [http://localhost:8000/api/analytics](http://localhost:8000/api/analytics)

---

## 🧪 Testing

Run the test suite:
```powershell
python -m pytest -v
```

The test suite validates:
- Multi-agent copywriting, review scoring, and scheduler optimization
- Persistent LangGraph workflow execution
- OAuth 2.0 PKCE generation, state validation, and token encryption
- Slack Block Kit message crafting, HMAC signature verification, and replay protection
- 4-Platform publishing (X, LinkedIn, Facebook, Instagram) with database account token decryption
- Publishing idempotency and double-execution protection
- REST API endpoints and end-to-end user workflows

---

## 🐳 Docker Deployment

### Run with Docker Compose (PostgreSQL + App):
```powershell
docker compose up --build
```

The Docker configuration automatically:
1. Boots the PostgreSQL 16 database with healthchecks.
2. Runs Alembic database migrations (`alembic upgrade head`).
3. Launches the FastAPI application on port 8000 with persistent state storage.

---

## 🔒 Security & Best Practices

- **Zero Hardcoded Secrets**: All credentials are dynamically loaded from environment variables.
- **Production Guardrails**: In `production` mode, the server rejects default development keys (`SECRET_KEY`, `FERNET_KEY`) during startup.
- **HMAC Slack Webhook Verification**: All incoming Slack webhook action callbacks are verified against `SLACK_SIGNING_SECRET` with anti-replay timestamp verification.
- **Idempotent Scheduler**: Background jobs check post status before executing and use atomic locks to prevent duplicate posts across workers.

---

## 📌 Known Limitations

- **Live Social Platform Credentials**: Testing real external publishing requires developer accounts on X, LinkedIn, and Meta. When credentials are not provided, the application runs in high-fidelity sandbox mode.
- **Instagram Feed Requirements**: Instagram Graph API requires media (image/video URL) for feed container creation; text-only Instagram posts are simulated or routed to supported media flows.

---

## 📂 Project Structure

```
ai-social-media-agent/
├── alembic/                            # Database migrations
├── backend/
│   └── app/
│       ├── main.py                     # FastAPI server, REST routes & static mounts
│       ├── config.py                   # Pydantic settings & environment configuration
│       ├── agents/
│       │   ├── content_agent.py        # LLM copywriter (OpenAI, Gemini, Anthropic & Mock)
│       │   ├── review_agent.py         # Automated compliance & virality critique
│       │   └── scheduler_agent.py     # Engagement time optimization
│       ├── graph/
│       │   ├── state.py                # LangGraph TypedDict state
│       │   ├── nodes.py                # Pipeline execution nodes
│       │   └── workflow.py             # Compiled state graph with persistent checkpointing
│       ├── integrations/
│       │   ├── slack.py                # Slack Block Kit notifier & HMAC verifier
│       │   ├── x_api.py                # X/Twitter v2 API connector with PKCE
│       │   ├── linkedin_api.py         # LinkedIn UGC API connector
│       │   ├── meta_api.py             # Meta Graph API connector (FB & IG)
│       │   └── mock_publisher.py       # High-fidelity sandbox publisher
│       ├── auth/
│       │   ├── oauth.py                # OAuth 2.0 PKCE flow manager
│       │   └── security.py             # AES-256 Fernet token encryption
│       ├── scheduler/
│       │   └── scheduler.py            # APScheduler engine
│       ├── database/
│       │   ├── database.py             # SQLAlchemy session & engine
│       │   ├── models.py               # Post, Account, Log, Approval models
│       │   └── crud.py                 # Query operations
│       └── services/
│           ├── content_service.py      # LangGraph workflow orchestration
│           └── publishing_service.py   # Multi-platform publishing dispatcher
├── frontend/
│   ├── index.html                      # Glassmorphic single page dashboard
│   ├── css/styles.css                  # Dark mode design system
│   └── js/app.js                       # Reactive state & API connectors
├── tests/
│   ├── test_agents.py
│   ├── test_workflow.py
│   ├── test_slack.py
│   └── test_publishing.py
├── run.py                              # Server launcher
├── Dockerfile
├── docker-compose.yml
└── requirements.txt
```
