// AI Social Media Agent — Web Client

const API_BASE = window.location.origin;

// State
let appState = {
  currentTab: 'dashboard',
  stats: {},
  posts: [],
  slackMessages: [],
  accounts: [],
  activePost: null
};

// DOM Loaded
document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initGenerator();
  initSlackEmulator();
  initAccounts();
  refreshAllData();

  // Auto poll stats & posts every 12 seconds
  setInterval(() => {
    fetchStats();
    if (appState.currentTab === 'calendar') fetchPosts();
    if (appState.currentTab === 'slack') fetchSlackMessages();
  }, 12000);
});

// Navigation Handling
function initNavigation() {
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const targetTab = item.dataset.tab;
      switchTab(targetTab);
    });
  });
}

function switchTab(tabId) {
  appState.currentTab = tabId;
  
  // Update sidebar active class
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.tab === tabId);
  });

  // Update tab pane visibility
  document.querySelectorAll('.tab-pane').forEach(pane => {
    pane.classList.toggle('active', pane.id === `tab-${tabId}`);
  });

  // Load specific data per tab
  if (tabId === 'dashboard') {
    fetchStats();
    fetchPosts();
  } else if (tabId === 'calendar') {
    fetchPosts();
  } else if (tabId === 'slack') {
    fetchSlackMessages();
  } else if (tabId === 'accounts') {
    fetchAccounts();
  }
}

// Refresh Master Data
async function refreshAllData() {
  await Promise.all([
    fetchStats(),
    fetchPosts(),
    fetchSlackMessages(),
    fetchAccounts()
  ]);
}

// --- Fetch Dashboard Stats ---
async function fetchStats() {
  try {
    const res = await fetch(`${API_BASE}/api/stats`);
    if (!res.ok) return;
    const data = await res.json();
    appState.stats = data;
    renderStats(data);
  } catch (err) {
    console.error("Failed to load stats:", err);
  }
}

function renderStats(stats) {
  document.getElementById('stat-total').textContent = stats.total_generated || 0;
  document.getElementById('stat-pending').textContent = stats.pending_approval || 0;
  document.getElementById('stat-scheduled').textContent = stats.scheduled || 0;
  document.getElementById('stat-published').textContent = stats.published || 0;
  document.getElementById('stat-score').textContent = (stats.average_quality_score || 0) + '%';
  
  const pendingBadge = document.getElementById('sidebar-pending-count');
  if (pendingBadge) {
    pendingBadge.textContent = stats.pending_approval || 0;
    pendingBadge.style.display = stats.pending_approval > 0 ? 'inline-block' : 'none';
  }
}

// --- Fetch & Render Posts List ---
async function fetchPosts() {
  try {
    const res = await fetch(`${API_BASE}/api/posts?limit=50`);
    if (!res.ok) return;
    const data = await res.json();
    appState.posts = data.posts || [];
    renderPostsTable(appState.posts);
    renderRecentDashboardPosts(appState.posts.slice(0, 5));
  } catch (err) {
    console.error("Failed to load posts:", err);
  }
}

function renderPostsTable(posts) {
  const tbody = document.getElementById('posts-table-body');
  if (!tbody) return;

  if (posts.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-dim); padding: 30px;">No posts generated yet. Head over to <b>Agent Studio</b> to generate one!</td></tr>`;
    return;
  }

  tbody.innerHTML = posts.map(p => {
    const targetBadges = (p.target_platforms || []).map(plt => {
      const cls = plt === 'TWITTER' ? 'badge-cyan' : (plt === 'LINKEDIN' ? 'badge-purple' : 'badge-green');
      return `<span class="stat-badge ${cls}">${plt}</span>`;
    }).join(' ');

    const dateStr = p.scheduled_time 
      ? `🕒 ${new Date(p.scheduled_time).toLocaleString([], {month:'short', day:'numeric', hour:'2-digit', minute:'2-digit'})}`
      : (p.published_at ? `✅ ${new Date(p.published_at).toLocaleDateString()}` : '—');

    return `
      <tr>
        <td><b>#${p.id}</b></td>
        <td>
          <div style="font-weight: 600; color: #fff;">${escapeHtml(p.topic)}</div>
          <div style="font-size: 0.8rem; color: var(--text-dim);">${escapeHtml(p.tone)}</div>
        </td>
        <td>${targetBadges}</td>
        <td>
          <span class="status-pill status-${p.status}">${p.status.replace('_', ' ')}</span>
        </td>
        <td>
          <span style="font-weight: 700; color: ${p.review_score >= 80 ? '#34d399' : '#fbbf24'};">${p.review_score || '—'}/100</span>
        </td>
        <td style="font-size: 0.85rem; color: var(--text-muted);">${dateStr}</td>
        <td>
          <div style="display: flex; gap: 6px;">
            <button class="btn btn-secondary" style="padding: 6px 10px; font-size: 0.8rem;" onclick="viewPostDetails(${p.id})">Inspect</button>
            ${p.status === 'PENDING_APPROVAL' ? `<button class="btn btn-primary" style="padding: 6px 10px; font-size: 0.8rem;" onclick="quickApprove(${p.id})">Approve</button>` : ''}
            <button class="btn btn-danger" style="padding: 6px 8px; font-size: 0.8rem;" onclick="deletePostItem(${p.id})">🗑️</button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function renderRecentDashboardPosts(posts) {
  const container = document.getElementById('recent-posts-list');
  if (!container) return;

  if (posts.length === 0) {
    container.innerHTML = `<p style="color: var(--text-dim); font-size: 0.9rem;">No recent activities found.</p>`;
    return;
  }

  container.innerHTML = posts.map(p => `
    <div style="padding: 12px 16px; background: rgba(255,255,255,0.02); border-radius: var(--radius-sm); border: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
      <div>
        <div style="font-weight: 600; font-size: 0.95rem; color: #fff;">${escapeHtml(p.topic)}</div>
        <div style="font-size: 0.8rem; color: var(--text-dim); margin-top: 2px;">
          Platforms: ${(p.target_platforms || []).join(', ')} • Score: <b>${p.review_score}/100</b>
        </div>
      </div>
      <div>
        <span class="status-pill status-${p.status}">${p.status.replace('_', ' ')}</span>
      </div>
    </div>
  `).join('');
}

// --- Generator Logic ---
function initGenerator() {
  const genBtn = document.getElementById('btn-generate-ai');
  if (!genBtn) return;

  genBtn.addEventListener('click', async () => {
    const topicInput = document.getElementById('input-topic');
    const toneSelect = document.getElementById('select-tone');
    const platformChecks = document.querySelectorAll('input[name="platforms"]:checked');

    const topic = topicInput.value.trim();
    if (!topic) {
      alert("Please enter a topic or theme for your social media post.");
      return;
    }

    const selectedPlatforms = Array.from(platformChecks).map(cb => cb.value);
    if (selectedPlatforms.length === 0) {
      alert("Please select at least one social media platform.");
      return;
    }

    // Set loading state
    genBtn.disabled = true;
    genBtn.innerHTML = `<span class="spinner"></span> Orchestrating LangGraph Agents...`;

    try {
      const res = await fetch(`${API_BASE}/api/posts/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic,
          tone: toneSelect.value,
          platforms: selectedPlatforms
        })
      });

      const data = await res.json();
      if (data.success && data.data) {
        renderGeneratedVariants(data.data);
        refreshAllData();
      } else {
        alert("Generation failed: " + (data.detail || "Unknown error"));
      }
    } catch (err) {
      console.error("Error during generation:", err);
      alert("Error invoking LangGraph workflow. Please check server logs.");
    } finally {
      genBtn.disabled = false;
      genBtn.innerHTML = `⚡ Generate AI Post Variants`;
    }
  });
}

function renderGeneratedVariants(data) {
  const container = document.getElementById('variants-output-container');
  const reviewScoreEl = document.getElementById('gen-review-score');
  const reviewNotesEl = document.getElementById('gen-review-feedback');
  const actionBanner = document.getElementById('gen-action-banner');

  if (!container) return;

  // Update Review Card
  if (reviewScoreEl) reviewScoreEl.textContent = `${data.review_score || 85}/100`;
  if (reviewNotesEl) reviewNotesEl.textContent = data.review_feedback || "Passed quality metrics.";
  if (actionBanner) {
    actionBanner.style.display = 'flex';
    actionBanner.dataset.postId = data.post_id;
  }

  const variants = data.variants || {};
  const cardsHtml = Object.entries(variants).map(([platform, text]) => {
    const icon = platform === 'TWITTER' ? '🐦 Twitter/X' : (platform === 'LINKEDIN' ? '💼 LinkedIn' : '📱 Meta');
    return `
      <div class="variant-card">
        <div class="variant-header">
          <span style="font-weight: 700; color: #818cf8;">${icon}</span>
          <span style="font-size: 0.75rem; color: var(--text-dim);">${text.length} characters</span>
        </div>
        <div class="variant-body">${escapeHtml(text)}</div>
        <div class="variant-footer">
          <span>Ready for publishing</span>
          <button class="btn btn-secondary" style="padding: 4px 10px; font-size: 0.75rem;" onclick="copyToClipboard('${escapeHtml(text).replace(/'/g, "\\'")}')">Copy</button>
        </div>
      </div>
    `;
  }).join('');

  container.innerHTML = cardsHtml;
  document.getElementById('generation-results-section').style.display = 'block';
  
  // Smooth scroll to results
  document.getElementById('generation-results-section').scrollIntoView({ behavior: 'smooth' });
}

// In-Generator Action Handlers
async function handleGeneratorDecision(action) {
  const banner = document.getElementById('gen-action-banner');
  const postId = banner ? banner.dataset.postId : null;
  if (!postId) return;

  try {
    const res = await fetch(`${API_BASE}/api/posts/${postId}/decision`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: action, reviewer: "Web Studio User" })
    });
    const result = await res.json();
    if (result.success) {
      alert(`Post #${postId} has been ${result.action.replace('_', ' ')}!`);
      switchTab('calendar');
      refreshAllData();
    }
  } catch (err) {
    console.error("Action error:", err);
  }
}

// --- Slack Interactive Emulator ---
async function fetchSlackMessages() {
  try {
    const res = await fetch(`${API_BASE}/api/slack/messages`);
    if (!res.ok) return;
    const data = await res.json();
    appState.slackMessages = data.messages || [];
    renderSlackMessages(appState.slackMessages);
  } catch (err) {
    console.error("Failed to load Slack messages:", err);
  }
}

function renderSlackMessages(messages) {
  const container = document.getElementById('slack-feed-container');
  if (!container) return;

  if (messages.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; color: var(--text-dim); padding: 40px;">
        <div style="font-size: 2rem; margin-bottom: 8px;">💬</div>
        <p>No active approval requests in Slack channel <b>#social-media-approvals</b>.</p>
        <p style="font-size: 0.85rem; margin-top: 6px;">Generate a new post in the Studio to see incoming Block Kit cards here!</p>
      </div>
    `;
    return;
  }

  container.innerHTML = messages.map(msg => {
    return `
      <div class="slack-box" id="slack-msg-${msg.post_id}">
        <div class="slack-header">
          <div class="slack-bot-avatar">🤖</div>
          <div>
            <div>AI Social Media Agent <span style="font-size: 0.75rem; color: #868686; font-weight: normal;">APP • ${msg.created_at}</span></div>
            <div style="font-size: 0.8rem; color: #94a3b8;">Channel: <b>${msg.channel}</b></div>
          </div>
        </div>
        <div class="slack-content">
          <div style="font-size: 1.05rem; font-weight: 700; margin-bottom: 8px; color: #fff;">
            Approval Required: ${escapeHtml(msg.topic)}
          </div>
          <div style="font-size: 0.85rem; color: #cbd5e1; margin-bottom: 12px;">
            Post ID: <code>#${msg.post_id}</code> • Status: ⏳ Pending Decision
          </div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button class="btn btn-success" style="padding: 8px 14px; font-size: 0.85rem;" onclick="triggerSlackInteractiveAction('approve_schedule_post', ${msg.post_id})">
              ✅ Approve & Schedule
            </button>
            <button class="btn btn-primary" style="padding: 8px 14px; font-size: 0.85rem;" onclick="triggerSlackInteractiveAction('publish_now_post', ${msg.post_id})">
              ⚡ Publish Now
            </button>
            <button class="btn btn-danger" style="padding: 8px 14px; font-size: 0.85rem;" onclick="triggerSlackInteractiveAction('reject_post', ${msg.post_id})">
              ❌ Reject / Redo
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

async function triggerSlackInteractiveAction(actionId, postId) {
  try {
    const payload = {
      type: "block_actions",
      user: { username: "slack_admin_demo" },
      actions: [
        {
          action_id: actionId,
          value: String(postId)
        }
      ]
    };

    const res = await fetch(`${API_BASE}/api/slack/actions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (data.status === 'handled') {
      alert(`Slack Action Dispatched: Successfully updated post #${postId}`);
      refreshAllData();
    }
  } catch (err) {
    console.error("Error triggering Slack action:", err);
  }
}

function initSlackEmulator() {
  const clearBtn = document.getElementById('btn-clear-slack');
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      appState.slackMessages = [];
      renderSlackMessages([]);
    });
  }
}

// --- Social Accounts & OAuth Management ---
async function fetchAccounts() {
  try {
    const res = await fetch(`${API_BASE}/api/accounts`);
    if (!res.ok) return;
    const data = await res.json();
    appState.accounts = data.accounts || [];
    renderAccounts(appState.accounts);
  } catch (err) {
    console.error("Failed to load accounts:", err);
  }
}

function renderAccounts(accounts) {
  const grid = document.getElementById('accounts-grid');
  if (!grid) return;

  const platforms = [
    { key: 'TWITTER', name: 'X / Twitter API v2', icon: '🐦', desc: 'Direct tweet dispatching & thread creation.' },
    { key: 'LINKEDIN', name: 'LinkedIn UGC API', icon: '💼', desc: 'Professional post sharing to company page or profile.' },
    { key: 'META_FACEBOOK', name: 'Meta Graph API', icon: '📱', desc: 'Facebook Page & Instagram Feed publishing.' }
  ];

  grid.innerHTML = platforms.map(p => {
    const connected = accounts.find(a => a.platform === p.key && a.is_active);
    return `
      <div class="card" style="display: flex; flex-direction: column; justify-content: space-between;">
        <div>
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div style="font-size: 1.8rem;">${p.icon}</div>
            <span class="stat-badge ${connected ? 'badge-green' : 'badge-amber'}">
              ${connected ? '● Connected' : '○ Sandbox Simulation'}
            </span>
          </div>
          <h3 style="font-size: 1.1rem; margin-bottom: 6px; color: #fff;">${p.name}</h3>
          <p style="font-size: 0.85rem; color: var(--text-muted); line-height: 1.5; margin-bottom: 16px;">${p.desc}</p>
          ${connected ? `<div style="font-size: 0.8rem; color: #6ee7b7; margin-bottom: 12px;">Account: <b>${escapeHtml(connected.account_name)}</b></div>` : ''}
        </div>
        <div style="display: flex; gap: 8px;">
          <button class="btn btn-secondary" style="flex: 1; font-size: 0.85rem;" onclick="openConnectModal('${p.key}', '${p.name}')">
            ${connected ? 'Reconfigure' : 'Connect Account'}
          </button>
        </div>
      </div>
    `;
  }).join('');
}

function openConnectModal(platformKey, platformName) {
  const modal = document.getElementById('account-modal');
  document.getElementById('modal-acc-platform').value = platformKey;
  document.getElementById('modal-acc-title').textContent = `Configure ${platformName}`;
  modal.classList.add('active');
}

function closeConnectModal() {
  document.getElementById('account-modal').classList.remove('active');
}

async function saveAccountCredentials() {
  const platform = document.getElementById('modal-acc-platform').value;
  const name = document.getElementById('modal-acc-name').value.trim() || `${platform.toLowerCase()}_user`;
  const token = document.getElementById('modal-acc-token').value.trim();

  try {
    const res = await fetch(`${API_BASE}/api/accounts/connect`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        platform: platform,
        account_name: name,
        access_token: token || "mock_token_key"
      })
    });
    if (res.ok) {
      closeConnectModal();
      refreshAllData();
      alert(`Successfully saved configuration for ${platform}!`);
    }
  } catch (err) {
    console.error("Account connect error:", err);
  }
}

// --- Post Details Inspector Modal ---
async function viewPostDetails(postId) {
  try {
    const res = await fetch(`${API_BASE}/api/posts/${postId}`);
    if (!res.ok) return;
    const post = await res.json();
    appState.activePost = post;

    const modal = document.getElementById('details-modal');
    document.getElementById('modal-details-title').textContent = `Post #${post.id} — ${post.topic}`;
    document.getElementById('modal-details-score').textContent = `${post.review_score}/100`;
    document.getElementById('modal-details-feedback').textContent = post.review_feedback || 'No critique logged.';

    const variantsBox = document.getElementById('modal-details-variants');
    variantsBox.innerHTML = Object.entries(post.platform_contents || {}).map(([plt, text]) => `
      <div style="background: rgba(15, 23, 42, 0.8); border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 12px; margin-bottom: 10px;">
        <div style="font-weight: 700; color: #818cf8; font-size: 0.85rem; margin-bottom: 6px;">${plt}</div>
        <div style="font-size: 0.9rem; white-space: pre-wrap; color: #e2e8f0;">${escapeHtml(text)}</div>
      </div>
    `).join('');

    const logsBox = document.getElementById('modal-details-logs');
    if ((post.publish_logs || []).length > 0) {
      logsBox.innerHTML = post.publish_logs.map(l => `
        <div style="font-size: 0.8rem; color: #94a3b8; margin-bottom: 4px;">
          • [${l.platform}] <b>${l.status}</b> — External ID: <code>${l.external_post_id || 'N/A'}</code> (${new Date(l.published_at).toLocaleTimeString()})
        </div>
      `).join('');
    } else {
      logsBox.innerHTML = `<span style="font-size: 0.8rem; color: var(--text-dim);">No publish attempts recorded yet.</span>`;
    }

    modal.classList.add('active');
  } catch (err) {
    console.error("Error loading post details:", err);
  }
}

function closeDetailsModal() {
  document.getElementById('details-modal').classList.remove('active');
}

// Quick Actions
async function quickApprove(postId) {
  try {
    const res = await fetch(`${API_BASE}/api/posts/${postId}/decision`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: "approve_schedule", reviewer: "Dashboard Quick Action" })
    });
    if (res.ok) {
      refreshAllData();
    }
  } catch (err) {
    console.error("Quick approve error:", err);
  }
}

async function deletePostItem(postId) {
  if (!confirm(`Are you sure you want to delete Post #${postId}?`)) return;
  try {
    const res = await fetch(`${API_BASE}/api/posts/${postId}`, { method: 'DELETE' });
    if (res.ok) {
      refreshAllData();
    }
  } catch (err) {
    console.error("Delete error:", err);
  }
}

// Utility
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => alert("Copied to clipboard!"));
}
