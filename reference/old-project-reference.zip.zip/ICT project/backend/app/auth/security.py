import base64
from cryptography.fernet import Fernet
from ..config import settings

class TokenSecurity:
    """Handles symmetric encryption and decryption of social media OAuth credentials."""

    def __init__(self):
        key = settings.get_fernet_key()
        self.fernet = Fernet(key)

    def encrypt(self, plain_token: str) -> str:
        if not plain_token:
            return ""
        return self.fernet.encrypt(plain_token.encode()).decode()

    def decrypt(self, cipher_token: str) -> str:
        if not cipher_token:
            return ""
        try:
            return self.fernet.decrypt(cipher_token.encode()).decode()
        except Exception:
            return ""

token_security = TokenSecurity()
