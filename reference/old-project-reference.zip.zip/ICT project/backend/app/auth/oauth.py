import time
import secrets
import hashlib
import base64
import logging
import urllib.parse
from typing import Dict, Any, Optional, Tuple
import httpx

from ..config import settings
from .security import token_security

logger = logging.getLogger(__name__)

class OAuthManager:
    """Manages multi-platform OAuth 2.0 authorization redirects, PKCE, state verification, and code exchanges."""

    # Authorization Endpoints
    AUTH_URLS = {
        "TWITTER": "https://twitter.com/i/oauth2/authorize",
        "LINKEDIN": "https://www.linkedin.com/oauth/v2/authorization",
        "META_FACEBOOK": "https://www.facebook.com/v19.0/dialog/oauth",
        "META_INSTAGRAM": "https://www.facebook.com/v19.0/dialog/oauth"
    }

    # Token Exchange Endpoints
    TOKEN_URLS = {
        "TWITTER": "https://api.twitter.com/2/oauth2/token",
        "LINKEDIN": "https://www.linkedin.com/oauth/v2/accessToken",
        "META_FACEBOOK": "https://graph.facebook.com/v19.0/oauth/access_token",
        "META_INSTAGRAM": "https://graph.facebook.com/v19.0/oauth/access_token"
    }

    def __init__(self):
        # In-memory store for pending OAuth states: {state: {"platform": str, "code_verifier": str, "redirect_uri": str, "created_at": float}}
        self._state_store: Dict[str, Dict[str, Any]] = {}
        self.state_ttl = 600  # 10 minutes TTL

    def _clean_expired_states(self):
        now = time.time()
        expired = [s for s, data in self._state_store.items() if now - data.get("created_at", 0) > self.state_ttl]
        for s in expired:
            self._state_store.pop(s, None)

    def generate_pkce(self) -> Tuple[str, str]:
        """Generates PKCE (code_verifier, code_challenge) using SHA-256."""
        code_verifier = secrets.token_urlsafe(64)
        digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
        code_challenge = base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")
        return code_verifier, code_challenge

    def create_oauth_state(self, platform: str, redirect_uri: str, code_verifier: Optional[str] = None) -> str:
        """Generates cryptographically secure random state and caches it with TTL."""
        self._clean_expired_states()
        state = secrets.token_urlsafe(32)
        self._state_store[state] = {
            "platform": platform.upper(),
            "redirect_uri": redirect_uri,
            "code_verifier": code_verifier,
            "created_at": time.time()
        }
        return state

    def validate_and_consume_state(self, state: str, platform: Optional[str] = None) -> Dict[str, Any]:
        """Validates state against store, checks expiration, and consumes it."""
        self._clean_expired_states()
        state_data = self._state_store.pop(state, None)
        if not state_data:
            raise ValueError("Invalid or expired OAuth state parameter.")
        if platform and state_data.get("platform") != platform.upper():
            raise ValueError(f"State platform mismatch: expected {platform}, got {state_data.get('platform')}")
        return state_data

    def get_authorization_url(self, platform: str, redirect_uri: str) -> str:
        """Constructs platform authorization URL with secure state and PKCE (where supported)."""
        platform_key = platform.upper()
        base_url = self.AUTH_URLS.get(platform_key)
        if not base_url:
            raise ValueError(f"Unsupported platform for OAuth: {platform}")

        code_verifier, code_challenge = self.generate_pkce()
        state = self.create_oauth_state(platform_key, redirect_uri, code_verifier=code_verifier)

        if platform_key in ("TWITTER", "X"):
            client_id = settings.X_CLIENT_ID or settings.X_API_KEY or "SAMPLE_X_CLIENT_ID"
            params = {
                "response_type": "code",
                "client_id": client_id,
                "redirect_uri": redirect_uri,
                "scope": "tweet.read tweet.write users.read offline.access",
                "state": state,
                "code_challenge": code_challenge,
                "code_challenge_method": "S256"
            }
        elif platform_key == "LINKEDIN":
            client_id = settings.LINKEDIN_CLIENT_ID or "SAMPLE_LINKEDIN_CLIENT_ID"
            params = {
                "response_type": "code",
                "client_id": client_id,
                "redirect_uri": redirect_uri,
                "scope": "openid profile email w_member_social",
                "state": state
            }
        elif platform_key in ("META_FACEBOOK", "META_INSTAGRAM"):
            client_id = settings.META_APP_ID or "SAMPLE_META_APP_ID"
            params = {
                "client_id": client_id,
                "redirect_uri": redirect_uri,
                "scope": "pages_show_list,pages_read_engagement,pages_manage_posts,instagram_basic,instagram_content_publish",
                "response_type": "code",
                "state": state
            }
        else:
            params = {"client_id": "dummy", "redirect_uri": redirect_uri, "state": state}

        return f"{base_url}?{urllib.parse.urlencode(params)}"

    async def exchange_code(
        self,
        platform: str,
        code: str,
        state: Optional[str] = None,
        redirect_uri: Optional[str] = None
    ) -> Dict[str, Any]:
        """Exchanges auth code for access & refresh tokens and account profile."""
        platform_key = platform.upper()
        code_verifier = None

        if state:
            state_data = self.validate_and_consume_state(state, platform_key)
            code_verifier = state_data.get("code_verifier")
            if not redirect_uri:
                redirect_uri = state_data.get("redirect_uri")

        # Fallback redirect URI if not provided
        if not redirect_uri:
            redirect_uri = "http://localhost:8000/api/accounts/oauth/callback"

        # Check if running in mock mode or live credentials are absent
        client_id_map = {
            "TWITTER": settings.X_CLIENT_ID or settings.X_API_KEY,
            "LINKEDIN": settings.LINKEDIN_CLIENT_ID,
            "META_FACEBOOK": settings.META_APP_ID,
            "META_INSTAGRAM": settings.META_APP_ID
        }
        configured_client_id = client_id_map.get(platform_key)

        if settings.MOCK_SOCIAL_PUBLISHING or not configured_client_id or code.startswith("mock_"):
            logger.info(f"Generating mock OAuth token exchange result for {platform_key}.")
            raw_token = f"mock_{platform_key.lower()}_token_{secrets.token_hex(16)}"
            raw_refresh = f"mock_{platform_key.lower()}_refresh_{secrets.token_hex(16)}"
            return {
                "success": True,
                "platform": platform_key,
                "account_name": f"Verified @{platform_key.lower()}_brand_account",
                "account_id": f"acc_{secrets.token_hex(6)}",
                "encrypted_access_token": token_security.encrypt(raw_token),
                "encrypted_refresh_token": token_security.encrypt(raw_refresh),
                "expires_in": 5184000,
                "token_type": "Bearer"
            }

        # Real Live OAuth 2.0 Exchanges
        async with httpx.AsyncClient(timeout=25.0) as client:
            if platform_key in ("TWITTER", "X"):
                return await self._exchange_twitter_code(client, code, redirect_uri, code_verifier)
            elif platform_key == "LINKEDIN":
                return await self._exchange_linkedin_code(client, code, redirect_uri)
            elif platform_key in ("META_FACEBOOK", "META_INSTAGRAM"):
                return await self._exchange_meta_code(client, code, redirect_uri, platform_key)
            else:
                raise ValueError(f"Unsupported OAuth platform: {platform}")

    async def _exchange_twitter_code(
        self,
        client: httpx.AsyncClient,
        code: str,
        redirect_uri: str,
        code_verifier: Optional[str]
    ) -> Dict[str, Any]:
        url = self.TOKEN_URLS["TWITTER"]
        client_id = settings.X_CLIENT_ID or settings.X_API_KEY
        client_secret = settings.X_CLIENT_SECRET or settings.X_API_SECRET

        payload = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "code_verifier": code_verifier or "challenge",
            "client_id": client_id
        }

        auth = None
        if client_secret:
            auth = (client_id, client_secret)

        resp = await client.post(url, data=payload, auth=auth)
        resp.raise_for_status()
        token_data = resp.json()

        access_token = token_data.get("access_token", "")
        refresh_token = token_data.get("refresh_token", "")
        expires_in = token_data.get("expires_in", 7200)

        # Retrieve user profile
        user_resp = await client.get(
            "https://api.twitter.com/2/users/me",
            headers={"Authorization": f"Bearer {access_token}"}
        )
        user_info = user_resp.json().get("data", {}) if user_resp.status_code == 200 else {}
        account_name = f"@{user_info.get('username', 'X_User')}"
        account_id = user_info.get("id", "")

        return {
            "success": True,
            "platform": "TWITTER",
            "account_name": account_name,
            "account_id": account_id,
            "encrypted_access_token": token_security.encrypt(access_token),
            "encrypted_refresh_token": token_security.encrypt(refresh_token) if refresh_token else None,
            "expires_in": expires_in,
            "token_type": "Bearer"
        }

    async def _exchange_linkedin_code(
        self,
        client: httpx.AsyncClient,
        code: str,
        redirect_uri: str
    ) -> Dict[str, Any]:
        url = self.TOKEN_URLS["LINKEDIN"]
        payload = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "client_id": settings.LINKEDIN_CLIENT_ID,
            "client_secret": settings.LINKEDIN_CLIENT_SECRET
        }

        resp = await client.post(url, data=payload)
        resp.raise_for_status()
        token_data = resp.json()

        access_token = token_data.get("access_token", "")
        refresh_token = token_data.get("refresh_token", "")
        expires_in = token_data.get("expires_in", 5184000)

        # Retrieve profile
        user_resp = await client.get(
            "https://api.linkedin.com/v2/userinfo",
            headers={"Authorization": f"Bearer {access_token}"}
        )
        user_info = user_resp.json() if user_resp.status_code == 200 else {}
        account_name = user_info.get("name", "LinkedIn Profile")
        account_id = user_info.get("sub", "")

        return {
            "success": True,
            "platform": "LINKEDIN",
            "account_name": account_name,
            "account_id": account_id,
            "encrypted_access_token": token_security.encrypt(access_token),
            "encrypted_refresh_token": token_security.encrypt(refresh_token) if refresh_token else None,
            "expires_in": expires_in,
            "token_type": "Bearer"
        }

    async def _exchange_meta_code(
        self,
        client: httpx.AsyncClient,
        code: str,
        redirect_uri: str,
        platform_key: str
    ) -> Dict[str, Any]:
        # Exchange code for short-lived user access token
        url = self.TOKEN_URLS["META_FACEBOOK"]
        params = {
            "client_id": settings.META_APP_ID,
            "client_secret": settings.META_APP_SECRET,
            "redirect_uri": redirect_uri,
            "code": code
        }
        resp = await client.get(url, params=params)
        resp.raise_for_status()
        token_data = resp.json()
        user_access_token = token_data.get("access_token", "")

        # Exchange for long-lived page token & accounts
        pages_resp = await client.get(
            "https://graph.facebook.com/v19.0/me/accounts",
            params={"access_token": user_access_token, "fields": "name,id,access_token,instagram_business_account"}
        )
        pages_data = pages_resp.json().get("data", []) if pages_resp.status_code == 200 else []

        page_name = "Meta Page"
        page_id = settings.META_PAGE_ID or ""
        page_token = user_access_token

        if pages_data:
            primary_page = pages_data[0]
            page_name = primary_page.get("name", "Facebook Page")
            page_id = primary_page.get("id", page_id)
            page_token = primary_page.get("access_token", user_access_token)

            if platform_key == "META_INSTAGRAM":
                ig_account = primary_page.get("instagram_business_account", {})
                if ig_account:
                    page_id = ig_account.get("id", page_id)
                    page_name = f"Instagram ({page_name})"

        return {
            "success": True,
            "platform": platform_key,
            "account_name": page_name,
            "account_id": page_id,
            "encrypted_access_token": token_security.encrypt(page_token),
            "encrypted_refresh_token": None,
            "expires_in": 5184000,
            "token_type": "Bearer"
        }

    async def refresh_access_token(self, platform: str, refresh_token: str) -> Optional[Dict[str, Any]]:
        """Refreshes expired OAuth 2.0 access token using refresh token."""
        platform_key = platform.upper()
        if settings.MOCK_SOCIAL_PUBLISHING or refresh_token.startswith("mock_"):
            new_token = f"mock_{platform_key.lower()}_refreshed_{secrets.token_hex(16)}"
            return {
                "access_token": new_token,
                "encrypted_access_token": token_security.encrypt(new_token),
                "expires_in": 7200
            }

        async with httpx.AsyncClient(timeout=20.0) as client:
            if platform_key in ("TWITTER", "X"):
                resp = await client.post(
                    self.TOKEN_URLS["TWITTER"],
                    data={
                        "grant_type": "refresh_token",
                        "refresh_token": refresh_token,
                        "client_id": settings.X_CLIENT_ID or settings.X_API_KEY
                    }
                )
                if resp.status_code == 200:
                    data = resp.json()
                    return {
                        "access_token": data.get("access_token"),
                        "encrypted_access_token": token_security.encrypt(data.get("access_token")),
                        "refresh_token": data.get("refresh_token"),
                        "encrypted_refresh_token": token_security.encrypt(data.get("refresh_token")) if data.get("refresh_token") else None,
                        "expires_in": data.get("expires_in", 7200)
                    }
        return None

oauth_manager = OAuthManager()

