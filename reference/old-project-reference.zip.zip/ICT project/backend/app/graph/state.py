from typing import TypedDict, List, Dict, Optional, Any

class SocialAgentState(TypedDict, total=False):
    # Inputs
    post_id: Optional[int]
    topic: str
    tone: str
    platforms: List[str]
    
    # Generation Stage
    variants: Dict[str, str]
    iteration_count: int
    
    # Review Stage
    review_score: int
    review_feedback: str
    review_passed: bool
    review_issues: List[str]
    
    # Scheduling Stage
    recommended_time: Optional[str]
    
    # Human-in-the-Loop & Execution Stage
    status: str
    human_approved: Optional[bool]
    human_feedback: Optional[str]
    slack_channel: Optional[str]
    slack_ts: Optional[str]
    
    # Metadata
    thread_id: str
    error: Optional[str]
