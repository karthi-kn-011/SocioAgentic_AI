import logging
from typing import Literal
from langgraph.graph import StateGraph, START, END
from .checkpoint import SqliteCheckpointSaver
from .state import SocialAgentState
from .nodes import (
    generate_node,
    review_node,
    schedule_advisor_node,
    persist_draft_node,
    slack_dispatch_node
)

logger = logging.getLogger(__name__)

def should_regenerate(state: SocialAgentState) -> Literal["generate", "persist_draft"]:
    """Conditional router: checks if post requires refinement or is ready for draft saving."""
    passed = state.get("review_passed", False)
    iterations = state.get("iteration_count", 0)
    
    # If passed or reached max auto-refinements (2 iterations), proceed to persist
    if passed or iterations >= 2:
        return "persist_draft"
    
    logger.info(f"Review score below threshold ({state.get('review_score')}), triggering self-correction loop.")
    return "generate"

def build_workflow() -> StateGraph:
    """Builds and compiles the multi-agent state graph."""
    workflow = StateGraph(SocialAgentState)

    # Add Nodes
    workflow.add_node("generate", generate_node)
    workflow.add_node("review", review_node)
    workflow.add_node("schedule_advisor", schedule_advisor_node)
    workflow.add_node("persist_draft", persist_draft_node)
    workflow.add_node("slack_dispatch", slack_dispatch_node)

    # Add Edges
    workflow.add_edge(START, "generate")
    workflow.add_edge("generate", "review")
    workflow.add_edge("review", "schedule_advisor")
    
    # Conditional edge based on review quality
    workflow.add_conditional_edges(
        "schedule_advisor",
        should_regenerate,
        {
            "generate": "generate",
            "persist_draft": "persist_draft"
        }
    )
    
    workflow.add_edge("persist_draft", "slack_dispatch")
    workflow.add_edge("slack_dispatch", END)

    return workflow

checkpointer = SqliteCheckpointSaver("social_agent_checkpoints.db")
social_graph = build_workflow().compile(checkpointer=checkpointer)

def compile_workflow():
    return social_graph

