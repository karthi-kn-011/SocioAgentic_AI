import sqlite3
import random
import os
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple, AsyncIterator
from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.base import (
    BaseCheckpointSaver,
    Checkpoint,
    CheckpointMetadata,
    CheckpointTuple,
    ChannelVersions,
    WRITES_IDX_MAP,
    get_checkpoint_metadata,
)

class SqliteCheckpointSaver(BaseCheckpointSaver):
    """Production-grade persistent SQLite checkpointer for LangGraph workflows.
    Ensures graph execution states and threads persist across server restarts.
    """

    def __init__(self, db_path: str = "social_agent_checkpoints.db"):
        super().__init__()
        self.db_path = db_path
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS checkpoints (
                    thread_id TEXT NOT NULL,
                    checkpoint_ns TEXT NOT NULL,
                    checkpoint_id TEXT NOT NULL,
                    parent_checkpoint_id TEXT,
                    type TEXT NOT NULL,
                    checkpoint BLOB NOT NULL,
                    metadata_type TEXT NOT NULL,
                    metadata BLOB NOT NULL,
                    PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id)
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS checkpoint_writes (
                    thread_id TEXT NOT NULL,
                    checkpoint_ns TEXT NOT NULL,
                    checkpoint_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    idx INTEGER NOT NULL,
                    channel TEXT NOT NULL,
                    type TEXT NOT NULL,
                    value BLOB NOT NULL,
                    task_path TEXT DEFAULT '',
                    PRIMARY KEY (thread_id, checkpoint_ns, checkpoint_id, task_id, idx)
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS checkpoint_blobs (
                    thread_id TEXT NOT NULL,
                    checkpoint_ns TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    version TEXT NOT NULL,
                    type TEXT NOT NULL,
                    blob BLOB NOT NULL,
                    PRIMARY KEY (thread_id, checkpoint_ns, channel, version)
                )
            """)
            conn.commit()

    def _load_blobs(self, thread_id: str, checkpoint_ns: str, versions: ChannelVersions) -> Dict[str, Any]:
        if not versions:
            return {}
        blobs: Dict[str, Any] = {}
        with self._get_connection() as conn:
            cursor = conn.cursor()
            for channel, version in versions.items():
                cursor.execute(
                    "SELECT type, blob FROM checkpoint_blobs WHERE thread_id = ? AND checkpoint_ns = ? AND channel = ? AND version = ?",
                    (thread_id, checkpoint_ns, channel, str(version))
                )
                row = cursor.fetchone()
                if row:
                    blobs[channel] = self.serde.loads_typed((row["type"], row["blob"]))
        return blobs

    def get_tuple(self, config: RunnableConfig) -> Optional[CheckpointTuple]:
        thread_id = config["configurable"]["thread_id"]
        checkpoint_ns = config["configurable"].get("checkpoint_ns", "")
        checkpoint_id = config["configurable"].get("checkpoint_id")

        with self._get_connection() as conn:
            cursor = conn.cursor()
            if checkpoint_id:
                cursor.execute(
                    "SELECT * FROM checkpoints WHERE thread_id = ? AND checkpoint_ns = ? AND checkpoint_id = ?",
                    (thread_id, checkpoint_ns, checkpoint_id)
                )
            else:
                cursor.execute(
                    "SELECT * FROM checkpoints WHERE thread_id = ? AND checkpoint_ns = ? ORDER BY checkpoint_id DESC LIMIT 1",
                    (thread_id, checkpoint_ns)
                )
            row = cursor.fetchone()
            if not row:
                return None

            raw_checkpoint = self.serde.loads_typed((row["type"], row["checkpoint"]))
            raw_metadata = self.serde.loads_typed((row["metadata_type"], row["metadata"]))
            parent_id = row["parent_checkpoint_id"]

            channel_values = self._load_blobs(thread_id, checkpoint_ns, raw_checkpoint.get("channel_versions", {}))
            checkpoint_obj = {**raw_checkpoint, "channel_values": channel_values}

            # Fetch pending writes
            cursor.execute(
                "SELECT task_id, channel, type, value, task_path FROM checkpoint_writes WHERE thread_id = ? AND checkpoint_ns = ? AND checkpoint_id = ? ORDER BY idx",
                (thread_id, checkpoint_ns, row["checkpoint_id"])
            )
            writes_rows = cursor.fetchall()
            pending_writes = [
                (w["task_id"], w["channel"], self.serde.loads_typed((w["type"], w["value"])))
                for w in writes_rows
            ]

            return CheckpointTuple(
                config={
                    "configurable": {
                        "thread_id": thread_id,
                        "checkpoint_ns": checkpoint_ns,
                        "checkpoint_id": row["checkpoint_id"]
                    }
                },
                checkpoint=checkpoint_obj,
                metadata=raw_metadata,
                parent_config=(
                    {
                        "configurable": {
                            "thread_id": thread_id,
                            "checkpoint_ns": checkpoint_ns,
                            "checkpoint_id": parent_id
                        }
                    }
                    if parent_id else None
                ),
                pending_writes=pending_writes
            )

    def list(
        self,
        config: Optional[RunnableConfig],
        *,
        filter: Optional[Dict[str, Any]] = None,
        before: Optional[RunnableConfig] = None,
        limit: Optional[int] = None
    ) -> Iterator[CheckpointTuple]:
        thread_id = config["configurable"]["thread_id"] if config else None
        checkpoint_ns = config["configurable"].get("checkpoint_ns", "") if config else ""

        with self._get_connection() as conn:
            cursor = conn.cursor()
            query = "SELECT * FROM checkpoints WHERE 1=1"
            params: List[Any] = []

            if thread_id:
                query += " AND thread_id = ? AND checkpoint_ns = ?"
                params.extend([thread_id, checkpoint_ns])
            if before and before["configurable"].get("checkpoint_id"):
                query += " AND checkpoint_id < ?"
                params.append(before["configurable"]["checkpoint_id"])

            query += " ORDER BY checkpoint_id DESC"
            if limit:
                query += f" LIMIT {int(limit)}"

            cursor.execute(query, params)
            rows = cursor.fetchall()

            for row in rows:
                t_id = row["thread_id"]
                ns = row["checkpoint_ns"]
                raw_checkpoint = self.serde.loads_typed((row["type"], row["checkpoint"]))
                raw_metadata = self.serde.loads_typed((row["metadata_type"], row["metadata"]))
                parent_id = row["parent_checkpoint_id"]
                channel_values = self._load_blobs(t_id, ns, raw_checkpoint.get("channel_versions", {}))
                checkpoint_obj = {**raw_checkpoint, "channel_values": channel_values}

                yield CheckpointTuple(
                    config={
                        "configurable": {
                            "thread_id": t_id,
                            "checkpoint_ns": ns,
                            "checkpoint_id": row["checkpoint_id"]
                        }
                    },
                    checkpoint=checkpoint_obj,
                    metadata=raw_metadata,
                    parent_config=(
                        {
                            "configurable": {
                                "thread_id": t_id,
                                "checkpoint_ns": ns,
                                "checkpoint_id": parent_id
                            }
                        }
                        if parent_id else None
                    )
                )

    def put(
        self,
        config: RunnableConfig,
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
        new_versions: ChannelVersions
    ) -> RunnableConfig:
        thread_id = config["configurable"]["thread_id"]
        checkpoint_ns = config["configurable"].get("checkpoint_ns", "")
        c = checkpoint.copy()
        values = c.pop("channel_values", {})

        with self._get_connection() as conn:
            cursor = conn.cursor()
            for k, v in new_versions.items():
                b_type, b_data = self.serde.dumps_typed(values[k]) if k in values else ("empty", b"")
                cursor.execute(
                    """
                    INSERT OR REPLACE INTO checkpoint_blobs (thread_id, checkpoint_ns, channel, version, type, blob)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (thread_id, checkpoint_ns, k, str(v), b_type, b_data)
                )

            c_type, c_data = self.serde.dumps_typed(c)
            m_type, m_data = self.serde.dumps_typed(get_checkpoint_metadata(config, metadata))
            parent_id = config["configurable"].get("checkpoint_id")

            cursor.execute(
                """
                INSERT OR REPLACE INTO checkpoints (thread_id, checkpoint_ns, checkpoint_id, parent_checkpoint_id, type, checkpoint, metadata_type, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (thread_id, checkpoint_ns, checkpoint["id"], parent_id, c_type, c_data, m_type, m_data)
            )
            conn.commit()

        return {
            "configurable": {
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": checkpoint["id"]
            }
        }

    def put_writes(
        self,
        config: RunnableConfig,
        writes: Sequence[Tuple[str, Any]],
        task_id: str,
        task_path: str = ""
    ) -> None:
        thread_id = config["configurable"]["thread_id"]
        checkpoint_ns = config["configurable"].get("checkpoint_ns", "")
        checkpoint_id = config["configurable"]["checkpoint_id"]

        with self._get_connection() as conn:
            cursor = conn.cursor()
            for idx, (c, v) in enumerate(writes):
                w_idx = WRITES_IDX_MAP.get(c, idx)
                v_type, v_data = self.serde.dumps_typed(v)
                cursor.execute(
                    """
                    INSERT OR REPLACE INTO checkpoint_writes (thread_id, checkpoint_ns, checkpoint_id, task_id, idx, channel, type, value, task_path)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (thread_id, checkpoint_ns, checkpoint_id, task_id, w_idx, c, v_type, v_data, task_path)
                )
            conn.commit()

    def delete_thread(self, thread_id: str) -> None:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM checkpoints WHERE thread_id = ?", (thread_id,))
            cursor.execute("DELETE FROM checkpoint_writes WHERE thread_id = ?", (thread_id,))
            cursor.execute("DELETE FROM checkpoint_blobs WHERE thread_id = ?", (thread_id,))
            conn.commit()

    async def aget_tuple(self, config: RunnableConfig) -> Optional[CheckpointTuple]:
        return self.get_tuple(config)

    async def alist(
        self,
        config: Optional[RunnableConfig],
        *,
        filter: Optional[Dict[str, Any]] = None,
        before: Optional[RunnableConfig] = None,
        limit: Optional[int] = None
    ) -> AsyncIterator[CheckpointTuple]:
        for item in self.list(config, filter=filter, before=before, limit=limit):
            yield item

    async def aput(
        self,
        config: RunnableConfig,
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
        new_versions: ChannelVersions
    ) -> RunnableConfig:
        return self.put(config, checkpoint, metadata, new_versions)

    async def aput_writes(
        self,
        config: RunnableConfig,
        writes: Sequence[Tuple[str, Any]],
        task_id: str,
        task_path: str = ""
    ) -> None:
        return self.put_writes(config, writes, task_id, task_path)

    async def adelete_thread(self, thread_id: str) -> None:
        return self.delete_thread(thread_id)

    def get_next_version(self, current: Optional[str], channel: None) -> str:
        if current is None:
            current_v = 0
        elif isinstance(current, int):
            current_v = current
        else:
            current_v = int(current.split(".")[0])
        next_v = current_v + 1
        next_h = random.random()
        return f"{next_v:032}.{next_h:016}"
