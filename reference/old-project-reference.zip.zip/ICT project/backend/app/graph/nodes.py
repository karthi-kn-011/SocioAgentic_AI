import logging
from typing import Dict, Any
from ..agents.content_agent import ContentGenerationAgent
from ..agents.review_agent import ContentReviewAgent
from ..agents.scheduler_agent import SchedulerOptimizationAgent
from ..database.database import SessionLocal
from ..database import crud, models
from ..integrations.slack import slack_notifier
from .state import SocialAgentState

logger = logging.getLogger(__name__)

content_agent = ContentGenerationAgent()
review_agent = ContentReviewAgent()
scheduler_agent = SchedulerOptimizationAgent()

async def generate_node(state: SocialAgentState) -> Dict[str, Any]:
    """Generates or refines multi-platform social media post variants."""
    topic = state.get("topic", "Tech Innovation")
    tone = state.get("tone", "Professional & Engaging")
    platforms = state.get("platforms", ["TWITTER", "LINKEDIN"])
    feedback = state.get("review_feedback") if state.get("iteration_count", 0) > 0 else None
    
    variants = await content_agent.generate_variants(
        topic=topic,
        tone=tone,
        platforms=platforms,
        feedback=feedback
    )
    
    iteration = state.get("iteration_count", 0) + 1
    return {
        "variants": variants,
        "iteration_count": iteration,
        "status": "GENERATED"
    }

async def review_node(state: SocialAgentState) -> Dict[str, Any]:
    """AI agent checks compliance, tone, hashtags, character constraints, and virality."""
    variants = state.get("variants", {})
    topic = state.get("topic", "")
    
    review_result = review_agent.review_variants(variants, topic)
    
    return {
        "review_score": review_result["score"],
        "review_passed": review_result["passed"],
        "review_feedback": review_result["feedback"],
        "review_issues": review_result.get("issues", []),
        "status": "REVIEWED"
    }

async def schedule_advisor_node(state: SocialAgentState) -> Dict[str, Any]:
    """Suggests optimal posting time based on platform analytics."""
    platforms = state.get("platforms", ["TWITTER", "LINKEDIN"])
    advice = scheduler_agent.recommend_optimal_slot(platforms)
    return {
        "recommended_time": advice["recommended_time"]
    }

async def persist_draft_node(state: SocialAgentState) -> Dict[str, Any]:
    """Persists the generated draft and review metadata to database."""
    db = SessionLocal()
    try:
        post_id = state.get("post_id")
        topic = state.get("topic", "")
        tone = state.get("tone", "")
        platforms = state.get("platforms", [])
        variants = state.get("variants", {})
        score = state.get("review_score", 0)
        feedback = state.get("review_feedback", "")
        passed = state.get("review_passed", True)
        thread_id = state.get("thread_id", "")
        
        if post_id:
            db_post = crud.update_post(
                db,
                post_id=post_id,
                platform_contents=variants,
                review_score=score,
                review_feedback=feedback,
                review_passed=passed,
                status=models.PostStatus.PENDING_APPROVAL
            )
        else:
            db_post = crud.create_post(
                db,
                topic=topic,
                tone=tone,
                target_platforms=platforms,
                platform_contents=variants,
                status=models.PostStatus.PENDING_APPROVAL,
                thread_id=thread_id
            )
            crud.update_post(
                db,
                post_id=db_post.id,
                review_score=score,
                review_feedback=feedback,
                review_passed=passed
            )
            post_id = db_post.id

        return {
            "post_id": post_id,
            "status": "PENDING_APPROVAL"
        }
    finally:
        db.close()

async def slack_dispatch_node(state: SocialAgentState) -> Dict[str, Any]:
    """Dispatches Slack interactive card for human-in-the-loop review."""
    post_id = state.get("post_id")
    topic = state.get("topic", "")
    variants = state.get("variants", {})
    score = state.get("review_score", 0)
    feedback = state.get("review_feedback", "")
    
    slack_res = await slack_notifier.send_approval_request(
        post_id=post_id,
        topic=topic,
        variants=variants,
        review_score=score,
        feedback=feedback
    )
    
    # Save approval record in database
    db = SessionLocal()
    try:
        if post_id:
            crud.create_approval_request(
                db,
                post_id=post_id,
                slack_channel=slack_res.get("channel"),
                slack_message_ts=slack_res.get("ts")
            )
    finally:
        db.close()

    return {
        "slack_channel": slack_res.get("channel"),
        "slack_ts": slack_res.get("ts"),
        "status": "AWAITING_HUMAN_APPROVAL"
    }
