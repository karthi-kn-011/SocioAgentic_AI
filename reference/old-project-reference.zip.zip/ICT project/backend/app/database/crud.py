from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from .models import Post, PostStatus, PlatformType, ApprovalRequest, SocialAccount, PublishLog

def get_utc_now():
    return datetime.now(timezone.utc)

# --- Post CRUD ---
def create_post(
    db: Session,
    topic: str,
    tone: str = "Professional & Engaging",
    target_platforms: Optional[List[str]] = None,
    raw_content: Optional[str] = None,
    platform_contents: Optional[Dict[str, str]] = None,
    status: PostStatus = PostStatus.DRAFT,
    thread_id: Optional[str] = None
) -> Post:
    if target_platforms is None:
        target_platforms = [PlatformType.TWITTER.value, PlatformType.LINKEDIN.value]
    if platform_contents is None:
        platform_contents = {}

    db_post = Post(
        topic=topic,
        tone=tone,
        target_platforms=target_platforms,
        raw_content=raw_content,
        platform_contents=platform_contents,
        status=status,
        thread_id=thread_id
    )
    db.add(db_post)
    db.commit()
    db.refresh(db_post)
    return db_post

def get_post_by_id(db: Session, post_id: int) -> Optional[Post]:
    return db.query(Post).filter(Post.id == post_id).first()

def get_posts(
    db: Session,
    skip: int = 0,
    limit: int = 50,
    status: Optional[PostStatus] = None
) -> List[Post]:
    query = db.query(Post)
    if status:
        query = query.filter(Post.status == status)
    return query.order_by(Post.created_at.desc()).offset(skip).limit(limit).all()

def update_post(
    db: Session,
    post_id: int,
    **kwargs
) -> Optional[Post]:
    db_post = get_post_by_id(db, post_id)
    if not db_post:
        return None
    for key, value in kwargs.items():
        if hasattr(db_post, key) and value is not None:
            setattr(db_post, key, value)
    db.commit()
    db.refresh(db_post)
    return db_post

def delete_post(db: Session, post_id: int) -> bool:
    db_post = get_post_by_id(db, post_id)
    if not db_post:
        return False
    db.delete(db_post)
    db.commit()
    return True

# --- Approval CRUD ---
def create_approval_request(
    db: Session,
    post_id: int,
    slack_channel: Optional[str] = None,
    slack_message_ts: Optional[str] = None
) -> ApprovalRequest:
    approval = ApprovalRequest(
        post_id=post_id,
        slack_channel=slack_channel,
        slack_message_ts=slack_message_ts,
        status="PENDING"
    )
    db.add(approval)
    db.commit()
    db.refresh(approval)
    return approval

def get_approval_by_post_id(db: Session, post_id: int) -> Optional[ApprovalRequest]:
    return db.query(ApprovalRequest).filter(ApprovalRequest.post_id == post_id).order_by(ApprovalRequest.created_at.desc()).first()

def record_approval_response(
    db: Session,
    approval_id: int,
    status: str,
    reviewer: str = "Human Reviewer",
    feedback: Optional[str] = None
) -> Optional[ApprovalRequest]:
    approval = db.query(ApprovalRequest).filter(ApprovalRequest.id == approval_id).first()
    if not approval:
        return None
    approval.status = status
    approval.reviewer = reviewer
    approval.feedback = feedback
    approval.responded_at = get_utc_now()
    db.commit()
    db.refresh(approval)
    return approval

# --- Social Accounts CRUD ---
def get_social_accounts(db: Session) -> List[SocialAccount]:
    return db.query(SocialAccount).all()

def get_social_account_by_platform(db: Session, platform: PlatformType) -> Optional[SocialAccount]:
    return db.query(SocialAccount).filter(SocialAccount.platform == platform, SocialAccount.is_active == True).first()

def upsert_social_account(
    db: Session,
    platform: PlatformType,
    account_name: str,
    account_id: Optional[str] = None,
    encrypted_access_token: Optional[str] = None,
    encrypted_refresh_token: Optional[str] = None,
    token_expires_at: Optional[datetime] = None,
    is_active: bool = True
) -> SocialAccount:
    account = db.query(SocialAccount).filter(SocialAccount.platform == platform).first()
    if account:
        account.account_name = account_name
        if account_id:
            account.account_id = account_id
        if encrypted_access_token:
            account.encrypted_access_token = encrypted_access_token
        if encrypted_refresh_token:
            account.encrypted_refresh_token = encrypted_refresh_token
        if token_expires_at:
            account.token_expires_at = token_expires_at
        account.is_active = is_active
        account.updated_at = get_utc_now()
    else:
        account = SocialAccount(
            platform=platform,
            account_name=account_name,
            account_id=account_id,
            encrypted_access_token=encrypted_access_token,
            encrypted_refresh_token=encrypted_refresh_token,
            token_expires_at=token_expires_at,
            is_active=is_active
        )
        db.add(account)
    db.commit()
    db.refresh(account)
    return account

# --- Publish Log CRUD ---
def create_publish_log(
    db: Session,
    post_id: int,
    platform: PlatformType,
    status: str,
    external_post_id: Optional[str] = None,
    response_payload: Optional[Dict[str, Any]] = None,
    error_message: Optional[str] = None
) -> PublishLog:
    log = PublishLog(
        post_id=post_id,
        platform=platform,
        status=status,
        external_post_id=external_post_id,
        response_payload=response_payload,
        error_message=error_message,
        published_at=get_utc_now()
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return log

