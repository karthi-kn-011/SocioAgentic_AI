import enum
import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, Enum, ForeignKey, Boolean, JSON
from sqlalchemy.orm import relationship
from .database import Base

def get_utc_now():
    return datetime.datetime.now(datetime.timezone.utc)

class PostStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    REVIEWING = "REVIEWING"
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    SCHEDULED = "SCHEDULED"
    PUBLISHING = "PUBLISHING"
    PUBLISHED = "PUBLISHED"
    FAILED = "FAILED"

class PlatformType(str, enum.Enum):
    TWITTER = "TWITTER"
    LINKEDIN = "LINKEDIN"
    META_FACEBOOK = "META_FACEBOOK"
    META_INSTAGRAM = "META_INSTAGRAM"

class Post(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True, index=True)
    topic = Column(String(255), nullable=False)
    tone = Column(String(100), default="Professional & Engaging")
    raw_content = Column(Text, nullable=True)
    platform_contents = Column(JSON, default=dict)  # {"TWITTER": "...", "LINKEDIN": "...", "META_FACEBOOK": "..."}
    target_platforms = Column(JSON, default=list)    # ["TWITTER", "LINKEDIN"]
    status = Column(Enum(PostStatus), default=PostStatus.DRAFT, index=True)
    
    # Review Metrics
    review_score = Column(Integer, default=0) # 0 - 100
    review_feedback = Column(Text, nullable=True)
    review_passed = Column(Boolean, default=False)
    
    # Scheduling & Execution
    scheduled_time = Column(DateTime, nullable=True, index=True)
    published_at = Column(DateTime, nullable=True)
    
    # LangGraph Thread ID
    thread_id = Column(String(100), nullable=True, index=True)
    
    created_at = Column(DateTime, default=get_utc_now)
    updated_at = Column(DateTime, default=get_utc_now, onupdate=get_utc_now)

    # Relationships
    approvals = relationship("ApprovalRequest", back_populates="post", cascade="all, delete-orphan")
    publish_logs = relationship("PublishLog", back_populates="post", cascade="all, delete-orphan")


class ApprovalRequest(Base):
    __tablename__ = "approval_requests"

    id = Column(Integer, primary_key=True, index=True)
    post_id = Column(Integer, ForeignKey("posts.id", ondelete="CASCADE"), nullable=False)
    slack_channel = Column(String(100), nullable=True)
    slack_message_ts = Column(String(100), nullable=True)
    status = Column(String(50), default="PENDING")  # PENDING, APPROVED, REJECTED, EDITED
    reviewer = Column(String(100), nullable=True)
    feedback = Column(Text, nullable=True)
    responded_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=get_utc_now)

    post = relationship("Post", back_populates="approvals")


class SocialAccount(Base):
    __tablename__ = "social_accounts"

    id = Column(Integer, primary_key=True, index=True)
    platform = Column(Enum(PlatformType), nullable=False)
    account_name = Column(String(150), nullable=False)
    account_id = Column(String(150), nullable=True)
    encrypted_access_token = Column(Text, nullable=True)
    encrypted_refresh_token = Column(Text, nullable=True)
    token_expires_at = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=get_utc_now)
    updated_at = Column(DateTime, default=get_utc_now, onupdate=get_utc_now)


class PublishLog(Base):
    __tablename__ = "publish_logs"

    id = Column(Integer, primary_key=True, index=True)
    post_id = Column(Integer, ForeignKey("posts.id", ondelete="CASCADE"), nullable=False)
    platform = Column(Enum(PlatformType), nullable=False)
    status = Column(String(50), nullable=False)  # SUCCESS, FAILED, SIMULATED
    response_payload = Column(JSON, nullable=True)
    error_message = Column(Text, nullable=True)
    external_post_id = Column(String(255), nullable=True)
    published_at = Column(DateTime, default=get_utc_now)

    post = relationship("Post", back_populates="publish_logs")

