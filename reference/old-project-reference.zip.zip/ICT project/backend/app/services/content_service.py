import logging
import uuid
import datetime
from typing import Dict, Any, List, Optional
from ..graph.workflow import social_graph
from ..graph.state import SocialAgentState
from ..database.database import SessionLocal
from ..database import crud, models
from .publishing_service import publishing_service

logger = logging.getLogger(__name__)

class ContentWorkflowService:
    """Manages LangGraph pipeline executions and Human-in-the-Loop resolutions."""

    async def start_generation_pipeline(
        self,
        topic: str,
        tone: str = "Professional & Engaging",
        platforms: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        if not platforms:
            platforms = ["TWITTER", "LINKEDIN", "META_FACEBOOK"]

        thread_id = str(uuid.uuid4())
        initial_state: SocialAgentState = {
            "topic": topic,
            "tone": tone,
            "platforms": platforms,
            "iteration_count": 0,
            "thread_id": thread_id,
            "status": "STARTING"
        }

        config = {"configurable": {"thread_id": thread_id}}
        
        # Execute LangGraph state machine
        final_state = await social_graph.ainvoke(initial_state, config=config)
        
        return {
            "thread_id": thread_id,
            "post_id": final_state.get("post_id"),
            "status": final_state.get("status"),
            "variants": final_state.get("variants"),
            "review_score": final_state.get("review_score"),
            "review_feedback": final_state.get("review_feedback"),
            "recommended_time": final_state.get("recommended_time")
        }

    async def handle_human_decision(
        self,
        post_id: int,
        action: str,  # "approve_schedule", "publish_now", "reject"
        reviewer: str = "Human Reviewer",
        feedback: Optional[str] = None,
        custom_scheduled_time: Optional[datetime.datetime] = None
    ) -> Dict[str, Any]:
        db = SessionLocal()
        try:
            post = crud.get_post_by_id(db, post_id)
            if not post:
                return {"success": False, "error": f"Post #{post_id} not found."}

            approval = crud.get_approval_by_post_id(db, post_id)
            if approval:
                crud.record_approval_response(
                    db,
                    approval_id=approval.id,
                    status=action.upper(),
                    reviewer=reviewer,
                    feedback=feedback
                )

            if action in ("approve_schedule", "approve"):
                target_time = custom_scheduled_time or (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=60))
                crud.update_post(
                    db,
                    post_id=post_id,
                    status=models.PostStatus.SCHEDULED,
                    scheduled_time=target_time
                )
                from ..scheduler.scheduler import app_scheduler
                app_scheduler.schedule_post(post_id, target_time)
                return {
                    "success": True,
                    "post_id": post_id,
                    "action": "APPROVED_AND_SCHEDULED",
                    "scheduled_time": target_time.isoformat()
                }

            elif action in ("publish_now", "instant_publish"):
                crud.update_post(db, post_id=post_id, status=models.PostStatus.APPROVED)
                # Dispatch immediate publish
                publish_res = await publishing_service.publish_post_now(post_id)
                return {
                    "success": True,
                    "post_id": post_id,
                    "action": "PUBLISHED_NOW",
                    "result": publish_res
                }

            elif action in ("reject", "redo"):
                crud.update_post(db, post_id=post_id, status=models.PostStatus.REJECTED)
                return {
                    "success": True,
                    "post_id": post_id,
                    "action": "REJECTED",
                    "feedback": feedback
                }

            return {"success": False, "error": f"Unknown action: {action}"}
        finally:
            db.close()

content_service = ContentWorkflowService()
