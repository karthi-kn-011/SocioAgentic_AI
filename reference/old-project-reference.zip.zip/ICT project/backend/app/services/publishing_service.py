import logging
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from ..database.database import SessionLocal
from ..database import crud, models
from ..auth.security import token_security
from ..auth.oauth import oauth_manager
from ..integrations.x_api import x_publisher
from ..integrations.linkedin_api import linkedin_publisher
from ..integrations.meta_api import meta_publisher

logger = logging.getLogger(__name__)

class PublishingService:
    """Orchestrates publishing across designated social media platform connectors with OAuth account integration."""

    async def publish_post_now(self, post_id: int) -> Dict[str, Any]:
        db = SessionLocal()
        try:
            post = crud.get_post_by_id(db, post_id)
            if not post:
                return {"success": False, "error": f"Post #{post_id} not found."}

            # Idempotency checks: Prevent duplicate publishing
            if post.status == models.PostStatus.PUBLISHED:
                logger.info(f"Post #{post_id} is already published. Skipping duplicate execution.")
                return {
                    "success": True,
                    "post_id": post_id,
                    "status": models.PostStatus.PUBLISHED.value,
                    "message": "Post has already been successfully published."
                }

            if post.status == models.PostStatus.PUBLISHING:
                logger.warning(f"Post #{post_id} is currently publishing in another task.")
                return {
                    "success": False,
                    "post_id": post_id,
                    "error": "Post publication is currently in progress."
                }

            # Mark post as PUBLISHING
            crud.update_post(db, post_id, status=models.PostStatus.PUBLISHING)
            
            platforms = post.target_platforms or ["TWITTER", "LINKEDIN"]
            variants = post.platform_contents or {}
            results = []
            overall_success = True

            for platform_str in platforms:
                platform_key = platform_str.upper()
                content = variants.get(platform_key, post.raw_content or post.topic)
                platform_enum = models.PlatformType(platform_key) if platform_key in models.PlatformType.__members__ else None

                # 1. Resolve connected SocialAccount & Decrypt OAuth Token
                account = crud.get_social_account_by_platform(db, platform_enum) if platform_enum else None
                decrypted_token: Optional[str] = None
                account_external_id: Optional[str] = None

                if account:
                    account_external_id = account.account_id
                    if account.encrypted_access_token:
                        decrypted_token = token_security.decrypt(account.encrypted_access_token)

                    # Check token expiration & refresh if needed
                    now_utc = datetime.now(timezone.utc)
                    if account.token_expires_at and account.token_expires_at <= now_utc and account.encrypted_refresh_token:
                        decrypted_refresh = token_security.decrypt(account.encrypted_refresh_token)
                        if decrypted_refresh:
                            refreshed = await oauth_manager.refresh_access_token(platform_key, decrypted_refresh)
                            if refreshed and refreshed.get("access_token"):
                                decrypted_token = refreshed["access_token"]
                                crud.upsert_social_account(
                                    db,
                                    platform=platform_enum,
                                    account_name=account.account_name,
                                    account_id=account.account_id,
                                    encrypted_access_token=refreshed.get("encrypted_access_token"),
                                    encrypted_refresh_token=refreshed.get("encrypted_refresh_token") or account.encrypted_refresh_token
                                )

                # 2. Dispatch to Platform Connector
                try:
                    if platform_key in ("TWITTER", "X"):
                        res = await x_publisher.post_tweet(content, access_token=decrypted_token)
                    elif platform_key == "LINKEDIN":
                        res = await linkedin_publisher.post_share(content, access_token=decrypted_token, author_urn=account_external_id)
                    elif platform_key == "META_FACEBOOK":
                        res = await meta_publisher.post_facebook(content, page_id=account_external_id, access_token=decrypted_token)
                    elif platform_key == "META_INSTAGRAM":
                        res = await meta_publisher.post_instagram(content, ig_user_id=account_external_id, access_token=decrypted_token)
                    else:
                        res = {"success": False, "platform": platform_key, "error": f"Unsupported platform {platform_key}"}
                    
                    results.append(res)
                    status_str = "SUCCESS" if res.get("success") else "FAILED"
                    if not res.get("success"):
                        overall_success = False

                    # 3. Record PublishLog (sanitized without credentials)
                    crud.create_publish_log(
                        db,
                        post_id=post_id,
                        platform=platform_enum or models.PlatformType.TWITTER,
                        status=status_str,
                        external_post_id=res.get("external_id"),
                        response_payload=res.get("response"),
                        error_message=res.get("error")
                    )
                except Exception as ex:
                    logger.error(f"Error publishing post {post_id} to {platform_key}: {ex}")
                    overall_success = False
                    crud.create_publish_log(
                        db,
                        post_id=post_id,
                        platform=platform_enum or models.PlatformType.TWITTER,
                        status="FAILED",
                        error_message=str(ex)
                    )

            final_status = models.PostStatus.PUBLISHED if overall_success else models.PostStatus.FAILED
            crud.update_post(
                db,
                post_id,
                status=final_status,
                published_at=datetime.now(timezone.utc) if overall_success else None
            )

            return {
                "success": overall_success,
                "post_id": post_id,
                "status": final_status.value,
                "platform_results": results
            }
        finally:
            db.close()

publishing_service = PublishingService()

