import logging
from typing import Dict, Any, Optional
import httpx
from ..config import settings
from .mock_publisher import mock_publisher

logger = logging.getLogger(__name__)

class MetaPublisher:
    """Meta (Facebook Page & Instagram Business) Graph API publisher."""

    async def post_facebook(self, text: str, page_id: Optional[str] = None, access_token: Optional[str] = None) -> Dict[str, Any]:
        token = access_token or settings.META_PAGE_ACCESS_TOKEN
        target_page_id = page_id or settings.META_PAGE_ID

        if settings.MOCK_SOCIAL_PUBLISHING or not (token and target_page_id):
            logger.info("Publishing to Facebook via Mock Publisher Simulator.")
            return await mock_publisher.publish_meta(text)

        url = f"https://graph.facebook.com/v19.0/{target_page_id}/feed"
        payload = {
            "message": text,
            "access_token": token
        }

        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                resp = await client.post(url, data=payload)
                resp.raise_for_status()
                data = resp.json()
                post_id = data.get("id", "")
                return {
                    "success": True,
                    "platform": "META_FACEBOOK",
                    "external_id": post_id,
                    "url": f"https://facebook.com/{post_id}",
                    "response": data
                }
        except Exception as e:
            logger.error(f"Failed to post to Facebook: {e}")
            return {"success": False, "platform": "META_FACEBOOK", "error": str(e)}

    async def post_instagram(
        self,
        text: str,
        ig_user_id: Optional[str] = None,
        access_token: Optional[str] = None,
        image_url: Optional[str] = None
    ) -> Dict[str, Any]:
        """Instagram Graph API publishing flow: Create media container -> Publish container."""
        token = access_token or settings.META_PAGE_ACCESS_TOKEN
        target_ig_id = ig_user_id or settings.INSTAGRAM_ACCOUNT_ID

        if settings.MOCK_SOCIAL_PUBLISHING or not (token and target_ig_id):
            logger.info("Publishing to Instagram via Mock Publisher Simulator.")
            return await mock_publisher.publish_instagram(text, image_url=image_url)

        # Instagram Feed requires a media container (image or video URL)
        media_url = image_url or "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe"

        try:
            async with httpx.AsyncClient(timeout=25.0) as client:
                # Step 1: Create IG media container
                container_url = f"https://graph.facebook.com/v19.0/{target_ig_id}/media"
                container_payload = {
                    "image_url": media_url,
                    "caption": text,
                    "access_token": token
                }
                c_resp = await client.post(container_url, data=container_payload)
                c_resp.raise_for_status()
                creation_id = c_resp.json().get("id")

                if not creation_id:
                    return {"success": False, "platform": "META_INSTAGRAM", "error": "Failed to create Instagram media container"}

                # Step 2: Publish container
                publish_url = f"https://graph.facebook.com/v19.0/{target_ig_id}/media_publish"
                p_resp = await client.post(publish_url, data={"creation_id": creation_id, "access_token": token})
                p_resp.raise_for_status()
                media_data = p_resp.json()
                media_id = media_data.get("id", creation_id)

                return {
                    "success": True,
                    "platform": "META_INSTAGRAM",
                    "external_id": media_id,
                    "url": f"https://instagram.com/p/{media_id}",
                    "response": media_data
                }
        except Exception as e:
            logger.error(f"Failed to post to Instagram: {e}")
            return {"success": False, "platform": "META_INSTAGRAM", "error": str(e)}

meta_publisher = MetaPublisher()

