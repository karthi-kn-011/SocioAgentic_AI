import logging
from typing import Dict, Any, Optional
import httpx
from ..config import settings
from .mock_publisher import mock_publisher

logger = logging.getLogger(__name__)

class LinkedInPublisher:
    """LinkedIn Share / UGC API publisher."""

    async def post_share(self, text: str, access_token: Optional[str] = None, author_urn: Optional[str] = None) -> Dict[str, Any]:
        token = access_token or settings.LINKEDIN_ACCESS_TOKEN
        
        if settings.MOCK_SOCIAL_PUBLISHING or not token:
            logger.info("Publishing to LinkedIn via Mock Publisher Simulator.")
            return await mock_publisher.publish_linkedin(text)

        url = "https://api.linkedin.com/v2/ugcPosts"
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Restli-Protocol-Version": "2.0.0",
            "Content-Type": "application/json"
        }
        
        author = author_urn or f"urn:li:organization:{settings.LINKEDIN_ORGANIZATION_ID or '1234567'}"
        payload = {
            "author": author,
            "lifecycleState": "PUBLISHED",
            "specificContent": {
                "com.linkedin.ugc.ShareContent": {
                    "shareCommentary": {"text": text},
                    "shareMediaCategory": "NONE"
                }
            },
            "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}
        }

        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                resp = await client.post(url, headers=headers, json=payload)
                resp.raise_for_status()
                data = resp.json()
                post_urn = data.get("id", "")
                return {
                    "success": True,
                    "platform": "LINKEDIN",
                    "external_id": post_urn,
                    "url": f"https://www.linkedin.com/feed/update/{post_urn}",
                    "response": data
                }
        except Exception as e:
            logger.error(f"Failed to post to LinkedIn: {e}")
            return {"success": False, "platform": "LINKEDIN", "error": str(e)}

linkedin_publisher = LinkedInPublisher()
