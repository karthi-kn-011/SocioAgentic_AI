import asyncio
import random
import time
from typing import Dict, Any

class MockSocialPublisher:
    """High-fidelity simulator for social media platform APIs."""

    async def publish_tweet(self, text: str) -> Dict[str, Any]:
        await asyncio.sleep(0.3)
        fake_id = f"17700{random.randint(10000000, 99999999)}"
        return {
            "success": True,
            "platform": "TWITTER",
            "external_id": fake_id,
            "url": f"https://x.com/brand_ai/status/{fake_id}",
            "response": {
                "data": {
                    "id": fake_id,
                    "text": text,
                    "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                }
            }
        }

    async def publish_linkedin(self, text: str) -> Dict[str, Any]:
        await asyncio.sleep(0.4)
        fake_urn = f"urn:li:share:{random.randint(7000000000000000000, 7999999999999999999)}"
        return {
            "success": True,
            "platform": "LINKEDIN",
            "external_id": fake_urn,
            "url": f"https://www.linkedin.com/feed/update/{fake_urn}",
            "response": {
                "id": fake_urn,
                "activity": f"urn:li:activity:{random.randint(7000000000000000000, 7999999999999999999)}"
            }
        }

    async def publish_meta(self, text: str) -> Dict[str, Any]:
        await asyncio.sleep(0.35)
        fake_id = f"10482937_{random.randint(100000000000, 999999999999)}"
        return {
            "success": True,
            "platform": "META_FACEBOOK",
            "external_id": fake_id,
            "url": f"https://facebook.com/{fake_id}",
            "response": {
                "id": fake_id,
                "post_supports_client_mutation_id": True
            }
        }

    async def publish_instagram(self, text: str, image_url: str = None) -> Dict[str, Any]:
        await asyncio.sleep(0.35)
        fake_id = f"179{random.randint(10000000000, 99999999999)}"
        return {
            "success": True,
            "platform": "META_INSTAGRAM",
            "external_id": fake_id,
            "url": f"https://instagram.com/p/{fake_id}",
            "response": {
                "id": fake_id,
                "media_type": "IMAGE" if image_url else "TEXT_STORY_SIMULATION",
                "caption": text
            }
        }

mock_publisher = MockSocialPublisher()

