import logging
import json
import time
import hmac
import hashlib
from typing import Dict, Any, Optional
from ..config import settings

logger = logging.getLogger(__name__)

class SlackNotifier:
    """Handles Slack Block Kit message crafting, signature verification, and interactive delivery."""

    def __init__(self):
        self.bot_token = settings.SLACK_BOT_TOKEN
        self.mock_mode = settings.SLACK_MOCK_MODE or not bool(settings.SLACK_BOT_TOKEN)
        self._mock_message_store = []  # Stores mock payloads for UI inspection & sandbox testing
        self._processed_action_triggers = set()  # Deduplication cache for action triggers

    def verify_slack_signature(self, request_body: bytes, timestamp: Optional[str], signature: Optional[str]) -> bool:
        """Verifies HMAC-SHA256 signature from Slack headers with anti-replay timestamp verification."""
        if self.mock_mode or not settings.SLACK_SIGNING_SECRET:
            return True
        
        if not timestamp or not signature:
            logger.warning("Slack signature verification rejected: Missing timestamp or signature header.")
            return False
            
        try:
            req_ts = int(timestamp)
            if abs(time.time() - req_ts) > 300:
                logger.warning(f"Slack signature verification failed: Timestamp out of range ({abs(time.time() - req_ts):.1f}s difference).")
                return False
        except (ValueError, TypeError):
            logger.warning("Slack signature verification rejected: Invalid timestamp format.")
            return False

        sig_basestring = f"v0:{timestamp}:".encode("utf-8") + request_body
        computed_signature = "v0=" + hmac.new(
            settings.SLACK_SIGNING_SECRET.encode("utf-8"),
            sig_basestring,
            hashlib.sha256
        ).hexdigest()

        is_valid = hmac.compare_digest(computed_signature, signature)
        if not is_valid:
            logger.warning("Slack signature mismatch.")
        return is_valid

    def get_mock_messages(self):
        return self._mock_message_store

    def clear_mock_messages(self):
        self._mock_message_store.clear()

    async def send_approval_request(
        self,
        post_id: int,
        topic: str,
        variants: Dict[str, str],
        review_score: int,
        feedback: str
    ) -> Dict[str, Any]:
        """Constructs Slack Block Kit JSON and posts to Slack channel or local mock store."""
        score_emoji = "🟢" if review_score >= 80 else ("🟡" if review_score >= 60 else "🔴")
        
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": "🤖 AI Social Media Agent — Post Approval Required",
                    "emoji": True
                }
            },
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*Topic:*\n{topic}"},
                    {"type": "mrkdwn", "text": f"*Post ID:*\n`#{post_id}`"},
                    {"type": "mrkdwn", "text": f"*AI Review Score:*\n{score_emoji} *{review_score}/100*"},
                    {"type": "mrkdwn", "text": f"*Status:*\n⏳ Pending Approval"}
                ]
            },
            {"type": "divider"}
        ]

        # Add section for each platform variant
        for platform, content in variants.items():
            icon = "🐦 Twitter/X" if platform == "TWITTER" else ("💼 LinkedIn" if platform == "LINKEDIN" else "📱 Meta")
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*{icon} Variant:*\n```{content}```"
                }
            })

        blocks.append({
            "type": "context",
            "elements": [
                {"type": "mrkdwn", "text": f"*AI Reviewer Notes:* {feedback}"}
            ]
        })

        # Interactive Action Buttons
        blocks.append({
            "type": "actions",
            "block_id": f"post_actions_{post_id}",
            "elements": [
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "✅ Approve & Schedule", "emoji": True},
                    "style": "primary",
                    "value": str(post_id),
                    "action_id": "approve_schedule_post"
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "⚡ Publish Now", "emoji": True},
                    "style": "primary",
                    "value": str(post_id),
                    "action_id": "publish_now_post"
                },
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "❌ Reject / Redo", "emoji": True},
                    "style": "danger",
                    "value": str(post_id),
                    "action_id": "reject_post"
                }
            ]
        })

        payload = {
            "channel": settings.SLACK_DEFAULT_CHANNEL,
            "text": f"New Social Media Post #{post_id} awaits your approval: {topic}",
            "blocks": blocks
        }

        # If live Slack token is set and mock mode disabled, send to real Slack
        if not self.mock_mode and self.bot_token:
            try:
                import httpx
                headers = {
                    "Authorization": f"Bearer {self.bot_token}",
                    "Content-Type": "application/json; charset=utf-8"
                }
                async with httpx.AsyncClient() as client:
                    resp = await client.post("https://slack.com/api/chat.postMessage", json=payload, headers=headers)
                    data = resp.json()
                    if data.get("ok"):
                        return {"ok": True, "ts": data.get("ts"), "channel": data.get("channel"), "blocks": blocks}
                    logger.warning(f"Slack API error: {data.get('error')}. Falling back to mock store.")
            except Exception as e:
                logger.error(f"Failed to post to Slack: {e}. Falling back to mock.")

        # Mock Mode delivery
        mock_ts = f"1710000000.{post_id:06d}"
        mock_record = {
            "ok": True,
            "ts": mock_ts,
            "channel": f"#{settings.SLACK_DEFAULT_CHANNEL}",
            "post_id": post_id,
            "topic": topic,
            "blocks": blocks,
            "created_at": "Just now"
        }
        self._mock_message_store.insert(0, mock_record)
        return mock_record

slack_notifier = SlackNotifier()
