import logging
from typing import Dict, Any, Optional
import httpx
from ..config import settings
from .mock_publisher import mock_publisher

logger = logging.getLogger(__name__)

class XPublisher:
    """X / Twitter API v2 publisher."""

    async def post_tweet(self, text: str, access_token: Optional[str] = None) -> Dict[str, Any]:
        token = access_token or settings.X_BEARER_TOKEN or settings.X_ACCESS_TOKEN
        
        # If mock mode is enabled or no credentials configured, use mock
        if settings.MOCK_SOCIAL_PUBLISHING or not token:
            logger.info("Publishing to X via Mock Publisher Simulator.")
            return await mock_publisher.publish_tweet(text)

        url = "https://api.twitter.com/2/tweets"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        payload = {"text": text}

        try:
            async with httpx.AsyncClient(timeout=20.0) as client:
                resp = await client.post(url, headers=headers, json=payload)
                resp.raise_for_status()
                data = resp.json()
                tweet_id = data.get("data", {}).get("id", "")
                return {
                    "success": True,
                    "platform": "TWITTER",
                    "external_id": tweet_id,
                    "url": f"https://x.com/i/web/status/{tweet_id}",
                    "response": data
                }
        except Exception as e:
            logger.error(f"Failed to post to X: {e}")
            return {"success": False, "platform": "TWITTER", "error": str(e)}

x_publisher = XPublisher()
