import logging
import asyncio
import datetime
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.date import DateTrigger
from apscheduler.triggers.interval import IntervalTrigger
from ..database.database import SessionLocal
from ..database import crud, models
from ..services.publishing_service import publishing_service

logger = logging.getLogger(__name__)

class AppScheduler:
    """Manages scheduled background publishing jobs."""

    def __init__(self):
        self.scheduler = AsyncIOScheduler()
        self._is_running = False

    def start(self):
        if not self._is_running:
            # Periodic check every 30 seconds for scheduled posts that are due
            self.scheduler.add_job(
                self.check_due_posts,
                trigger=IntervalTrigger(seconds=30),
                id="check_due_posts_job",
                replace_existing=True
            )
            self.scheduler.start()
            self._is_running = True
            logger.info("APScheduler initialized and running.")

    def shutdown(self):
        if self._is_running:
            self.scheduler.shutdown()
            self._is_running = False
            logger.info("APScheduler shut down.")

    def schedule_post(self, post_id: int, run_date: datetime.datetime):
        job_id = f"publish_post_{post_id}"
        self.scheduler.add_job(
            publishing_service.publish_post_now,
            trigger=DateTrigger(run_date=run_date),
            args=[post_id],
            id=job_id,
            replace_existing=True
        )
        logger.info(f"Scheduled post #{post_id} for execution at {run_date} (Job: {job_id})")

    async def check_due_posts(self):
        """Scans database for any posts past their scheduled time that need execution."""
        db = SessionLocal()
        try:
            now = datetime.datetime.now(datetime.timezone.utc)
            # Support both timezone-aware and naive SQLite timestamps
            due_posts = (
                db.query(models.Post)
                .filter(
                    models.Post.status == models.PostStatus.SCHEDULED,
                    (models.Post.scheduled_time <= now) | (models.Post.scheduled_time <= now.replace(tzinfo=None))
                )
                .all()
            )
            for post in due_posts:
                logger.info(f"Triggering due scheduled post #{post.id}")
                await publishing_service.publish_post_now(post.id)
        except Exception as e:
            logger.error(f"Error in scheduler check_due_posts: {e}")
        finally:
            db.close()

app_scheduler = AppScheduler()
