import os
import logging
from typing import Optional
from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)

class Settings(BaseSettings):
    APP_NAME: str = "AI-Social-Media-Agent"
    ENVIRONMENT: str = "development"
    PORT: int = 8000
    HOST: str = "0.0.0.0"
    SECRET_KEY: str = "dev-secret-key-replace-in-prod-32-chars-min!"
    FERNET_KEY: Optional[str] = None
    
    # Database
    DATABASE_URL: str = "sqlite:///./social_agent.db"
    
    # LLM Settings
    DEFAULT_LLM_PROVIDER: str = "mock"  # "mock", "openai", "anthropic", "gemini"
    OPENAI_API_KEY: Optional[str] = None
    ANTHROPIC_API_KEY: Optional[str] = None
    GEMINI_API_KEY: Optional[str] = None
    
    # Slack HITL Settings
    SLACK_BOT_TOKEN: Optional[str] = None
    SLACK_SIGNING_SECRET: Optional[str] = None
    SLACK_DEFAULT_CHANNEL: str = "social-media-approvals"
    SLACK_MOCK_MODE: bool = True
    
    # Social Media Publishing Settings
    MOCK_SOCIAL_PUBLISHING: bool = True
    
    # X / Twitter
    X_API_KEY: Optional[str] = None
    X_API_SECRET: Optional[str] = None
    X_CLIENT_ID: Optional[str] = None
    X_CLIENT_SECRET: Optional[str] = None
    X_ACCESS_TOKEN: Optional[str] = None
    X_ACCESS_SECRET: Optional[str] = None
    X_BEARER_TOKEN: Optional[str] = None
    X_REDIRECT_URI: Optional[str] = None
    
    # LinkedIn
    LINKEDIN_CLIENT_ID: Optional[str] = None
    LINKEDIN_CLIENT_SECRET: Optional[str] = None
    LINKEDIN_ACCESS_TOKEN: Optional[str] = None
    LINKEDIN_ORGANIZATION_ID: Optional[str] = None
    LINKEDIN_REDIRECT_URI: Optional[str] = None
    
    # Meta / Facebook / Instagram
    META_APP_ID: Optional[str] = None
    META_APP_SECRET: Optional[str] = None
    META_PAGE_ACCESS_TOKEN: Optional[str] = None
    META_PAGE_ID: Optional[str] = None
    META_REDIRECT_URI: Optional[str] = None
    INSTAGRAM_ACCOUNT_ID: Optional[str] = None

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @model_validator(mode="after")
    def validate_production_security(self) -> "Settings":
        if self.ENVIRONMENT.lower() == "production":
            dev_default_secret = "dev-secret-key-replace-in-prod-32-chars-min!"
            if self.SECRET_KEY == dev_default_secret or len(self.SECRET_KEY) < 32:
                raise ValueError("In production, SECRET_KEY must be explicitly set and at least 32 characters.")
            if not self.FERNET_KEY:
                raise ValueError("In production, FERNET_KEY must be explicitly configured for secure token encryption.")
            try:
                Fernet(self.FERNET_KEY.encode())
            except Exception as e:
                raise ValueError(f"Invalid FERNET_KEY for production: {e}")
        return self

    def get_fernet_key(self) -> bytes:
        if self.FERNET_KEY:
            return self.FERNET_KEY.encode()
        # Fallback only for non-production development environments
        return b"4P5N13pX0mBfPj5f2Z_h-XUqY1tPqBvR7wJ6xK9eT0g="

settings = Settings()

