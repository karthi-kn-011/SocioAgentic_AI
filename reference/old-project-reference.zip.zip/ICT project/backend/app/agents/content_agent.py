import os
import json
import logging
from typing import Dict, List, Optional
import httpx
from ..config import settings

logger = logging.getLogger(__name__)

class ContentGenerationAgent:
    """Agent responsible for crafting platform-specific social media copy."""

    def __init__(self, provider: Optional[str] = None):
        self.provider = provider or settings.DEFAULT_LLM_PROVIDER

    async def generate_variants(
        self,
        topic: str,
        tone: str = "Professional & Engaging",
        platforms: Optional[List[str]] = None,
        feedback: Optional[str] = None
    ) -> Dict[str, str]:
        if platforms is None:
            platforms = ["TWITTER", "LINKEDIN", "META_FACEBOOK"]

        # Check if live LLM keys are configured
        if self.provider == "openai" and settings.OPENAI_API_KEY:
            return await self._generate_openai(topic, tone, platforms, feedback)
        elif self.provider == "gemini" and settings.GEMINI_API_KEY:
            return await self._generate_gemini(topic, tone, platforms, feedback)
        else:
            return self._generate_mock_intelligent(topic, tone, platforms, feedback)

    async def _generate_openai(
        self, topic: str, tone: str, platforms: List[str], feedback: Optional[str]
    ) -> Dict[str, str]:
        prompt = self._build_prompt(topic, tone, platforms, feedback)
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {settings.OPENAI_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "gpt-4o-mini",
            "messages": [
                {"role": "system", "content": "You are an elite social media manager and copywriter."},
                {"role": "user", "content": prompt}
            ],
            "response_format": {"type": "json_object"}
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            res = await client.post(url, headers=headers, json=payload)
            res.raise_for_status()
            data = res.json()
            content = data["choices"][0]["message"]["content"]
            return json.loads(content)

    async def _generate_gemini(
        self, topic: str, tone: str, platforms: List[str], feedback: Optional[str]
    ) -> Dict[str, str]:
        prompt = self._build_prompt(topic, tone, platforms, feedback)
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={settings.GEMINI_API_KEY}"
        payload = {
            "contents": [{
                "parts": [{"text": prompt + "\nRespond ONLY with a valid JSON object mapping platform name to post text."}]
            }],
            "generationConfig": {"response_mime_type": "application/json"}
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            res = await client.post(url, json=payload)
            res.raise_for_status()
            data = res.json()
            text = data["candidates"][0]["content"]["parts"][0]["text"]
            return json.loads(text)

    def _build_prompt(self, topic: str, tone: str, platforms: List[str], feedback: Optional[str]) -> str:
        prompt = (
            f"Generate high-performing social media posts for topic: '{topic}'.\n"
            f"Tone: '{tone}'.\n"
            f"Target Platforms: {', '.join(platforms)}.\n"
        )
        if feedback:
            prompt += f"Incorporate this feedback from prior review: '{feedback}'.\n"
        prompt += (
            "Return a JSON object where keys are the platform names ("
            + ", ".join(f'"{p}"' for p in platforms)
            + ") and values are the formatted post strings.\n"
            "- TWITTER: Max 280 chars, punchy hook, 2-3 hashtags, emojis.\n"
            "- LINKEDIN: Professional storytelling, structured paragraphs, insights, actionable takeaways, call to action, 3-5 hashtags.\n"
            "- META_FACEBOOK: Conversational, community-centric, question hook, emojis.\n"
            "- META_INSTAGRAM: Visual description hook, engaging caption, carousel suggestions, curated hashtag bank."
        )
        return prompt

    def _generate_mock_intelligent(
        self, topic: str, tone: str, platforms: List[str], feedback: Optional[str]
    ) -> Dict[str, str]:
        """High quality deterministic/generative mock variant generator."""
        clean_topic = topic.strip().capitalize()
        results = {}

        # Keywords for hashtags
        words = [w for w in clean_topic.replace(",", " ").replace("-", " ").split() if len(w) > 3]
        hashtags = " ".join([f"#{w.capitalize()}" for w in words[:3]]) or "#TechTrends #Innovation #Future"

        if "TWITTER" in platforms:
            rev_note = f" (Refined: {feedback[:30]}...)" if feedback else ""
            tweet = (
                f"🚀 Big things happening in {clean_topic}!\n\n"
                f"Key takeaway: Staying ahead means embracing adaptive strategies and agile workflows{rev_note}.\n\n"
                f"What's your take? 👇\n{hashtags} #SocialTech"
            )
            # Ensure under 280 chars
            if len(tweet) > 275:
                tweet = tweet[:270] + "..."
            results["TWITTER"] = tweet

        if "LINKEDIN" in platforms:
            results["LINKEDIN"] = (
                f"💡 Rethinking {clean_topic}: Why Modern Teams Must Adapt\n\n"
                f"In today's fast-moving landscape, conversations around {clean_topic} are evolving quickly. "
                f"Here are 3 key principles driving impact:\n\n"
                f"1️⃣ Consistency over complexity: Streamlined systems win every time.\n"
                f"2️⃣ Human-in-the-loop oversight: Pairing automation with strategic human judgment.\n"
                f"3️⃣ Data-backed execution: Measuring outcomes, not just activity.\n\n"
                f"👉 How is your organization approaching {clean_topic} this quarter? Let's connect and discuss in the comments.\n\n"
                f"{hashtags} #Leadership #Strategy #Growth"
            )

        if "META_FACEBOOK" in platforms:
            results["META_FACEBOOK"] = (
                f"✨ Let's talk about {clean_topic}! ✨\n\n"
                f"We're seeing an incredible shift in how people and teams approach this space. "
                f"Whether you're just getting started or scaling up, the key is staying curious and consistent.\n\n"
                f"Drop a comment below: What's one thing you've learned about {clean_topic} recently? 💬👇\n\n"
                f"{hashtags}"
            )

        if "META_INSTAGRAM" in platforms:
            results["META_INSTAGRAM"] = (
                f"Swipe for the breakdown on {clean_topic} ➡️📲\n\n"
                f"The future belongs to those who build smart, iterate fast, and stay authentic.\n\n"
                f"Save this post for your next strategy session! 📌\n\n"
                f".\n.\n.\n"
                f"{hashtags} #Creators #DailyInspiration #Productivity"
            )

        return results
