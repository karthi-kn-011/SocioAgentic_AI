import datetime
from typing import Dict, Any, List

class SchedulerOptimizationAgent:
    """Agent that analyzes platform heuristics and computes optimal posting schedule windows."""

    # Peak platform engagement time windows (Hour in 24h format)
    OPTIMAL_HOURS = {
        "TWITTER": [9, 12, 17],     # 9 AM, 12 PM, 5 PM
        "LINKEDIN": [8, 10, 14],    # 8 AM, 10 AM, 2 PM (Business hours)
        "META_FACEBOOK": [13, 15, 19], # 1 PM, 3 PM, 7 PM
        "META_INSTAGRAM": [11, 14, 20] # 11 AM, 2 PM, 8 PM
    }

    def recommend_optimal_slot(self, platforms: List[str], base_time: datetime.datetime = None) -> Dict[str, Any]:
        if base_time is None:
            base_time = datetime.datetime.now(datetime.timezone.utc)

        # Find the next best time slot at least 30 minutes in the future
        target_time = base_time + datetime.timedelta(minutes=30)
        
        # Pick primary platform heuristic
        primary = platforms[0] if platforms else "TWITTER"
        preferred_hours = self.OPTIMAL_HOURS.get(primary, [10, 14, 18])

        # Find closest preferred hour today or tomorrow
        chosen_hour = preferred_hours[0]
        for h in preferred_hours:
            candidate = target_time.replace(hour=h, minute=0, second=0, microsecond=0)
            if candidate > target_time:
                chosen_hour = h
                break
        else:
            # Roll over to tomorrow's first preferred slot
            target_time = target_time + datetime.timedelta(days=1)
            chosen_hour = preferred_hours[0]

        scheduled_slot = target_time.replace(hour=chosen_hour, minute=0, second=0, microsecond=0)

        return {
            "recommended_time": scheduled_slot.isoformat(),
            "target_hour": chosen_hour,
            "primary_platform": primary,
            "rationale": f"High engagement cluster for {primary} audience during local peak hours ({chosen_hour}:00)."
        }
