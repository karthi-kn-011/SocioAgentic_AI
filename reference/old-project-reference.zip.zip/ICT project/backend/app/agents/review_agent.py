import logging
from typing import Dict, Any, Tuple

logger = logging.getLogger(__name__)

class ContentReviewAgent:
    """Agent that critiques, validates, and quality-checks draft content against platform policies."""

    def review_variants(self, variants: Dict[str, str], topic: str) -> Dict[str, Any]:
        issues = []
        scores = []

        for platform, text in variants.items():
            platform_score, platform_issues = self._evaluate_single(platform, text, topic)
            scores.append(platform_score)
            issues.extend(platform_issues)

        avg_score = int(sum(scores) / len(scores)) if scores else 80
        passed = avg_score >= 70 and not any("CRITICAL" in iss for iss in issues)

        feedback_summary = (
            "Content passed quality & brand guidelines successfully. Clear call to action and platform-adapted formatting."
            if passed
            else "Needs adjustment: " + "; ".join(issues)
        )

        return {
            "score": avg_score,
            "passed": passed,
            "feedback": feedback_summary,
            "issues": issues,
            "readability": "High",
            "sentiment": "Positive / Inspiring",
            "compliance_checked": True
        }

    def _evaluate_single(self, platform: str, text: str, topic: str) -> Tuple[int, list]:
        score = 90
        issues = []

        if not text or len(text.strip()) < 10:
            return 20, [f"CRITICAL: {platform} post is too short or empty."]

        # Check Twitter / X length
        if platform == "TWITTER":
            if len(text) > 280:
                score -= 30
                issues.append(f"CRITICAL: Twitter post exceeds 280 characters ({len(text)} chars).")
            elif len(text) < 50:
                score -= 10
                issues.append("Twitter post could use a stronger hook or hashtag.")

        # Check hashtags
        if "#" not in text:
            score -= 10
            issues.append(f"Suggestion: Add 1-3 hashtags to {platform} post for discoverability.")

        # Check LinkedIn structure
        if platform == "LINKEDIN":
            if "\n" not in text:
                score -= 15
                issues.append("LinkedIn post should have line breaks for readability.")

        # Spammy / offensive words check (toy safety filter)
        banned_words = ["guaranteed profit", "free crypto", "act now or die", "scam"]
        for bad in banned_words:
            if bad in text.lower():
                score -= 50
                issues.append(f"CRITICAL: Flagged policy violation keyword '{bad}' detected.")

        return max(score, 10), issues
