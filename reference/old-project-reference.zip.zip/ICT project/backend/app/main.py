import os
import json
import logging
from typing import List, Optional, Dict, Any
from datetime import datetime
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, Query, Request, Body, Form, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from .config import settings
from .database.database import init_db, get_db
from .database import crud, models
from .scheduler.scheduler import app_scheduler
from .services.content_service import content_service
from .services.publishing_service import publishing_service
from .services.image_service import image_service
from .integrations.slack import slack_notifier
from .auth.oauth import oauth_manager
from .auth.security import token_security

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("SocialAgentApp")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Initializing Database...")
    init_db()
    logger.info("Starting Scheduler...")
    app_scheduler.start()
    yield
    # Shutdown
    logger.info("Shutting down Scheduler...")
    app_scheduler.shutdown()

app = FastAPI(
    title="AI Social Media Agent API",
    description="Multi-agent social media management system with LangGraph, Slack HITL, APScheduler, and platform APIs.",
    version="1.0.0",
    lifespan=lifespan
)

# Enable CORS for frontend flexibility
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Pydantic Request/Response Schemas ---
class GeneratePostRequest(BaseModel):
    topic: str = Field(..., min_length=3, max_length=500, description="Post topic or theme")
    tone: str = Field("Professional & Engaging", min_length=2, max_length=100)
    platforms: List[str] = Field(default_factory=lambda: ["TWITTER", "LINKEDIN", "META_FACEBOOK"])

class PostDecisionRequest(BaseModel):
    action: str = Field(..., description="Action: approve_schedule, publish_now, reject")
    reviewer: str = Field("Human Reviewer", max_length=100)
    feedback: Optional[str] = None
    custom_scheduled_time: Optional[datetime] = None

class UpdatePostRequest(BaseModel):
    topic: Optional[str] = Field(None, min_length=1, max_length=500)
    tone: Optional[str] = None
    platform_contents: Optional[Dict[str, str]] = None
    scheduled_time: Optional[datetime] = None

class ConnectAccountRequest(BaseModel):
    platform: str
    account_name: str = Field(..., min_length=1, max_length=150)
    account_id: Optional[str] = None
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None

class ImageGenerateRequest(BaseModel):
    topic: str
    style_prompt: Optional[str] = None

# --- API Endpoints ---

@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "service": settings.APP_NAME,
        "environment": settings.ENVIRONMENT,
        "scheduler_running": app_scheduler._is_running,
        "mock_publishing": settings.MOCK_SOCIAL_PUBLISHING,
        "mock_slack": settings.SLACK_MOCK_MODE
    }

@app.post("/api/posts/generate", status_code=status.HTTP_201_CREATED)
async def generate_post(req: GeneratePostRequest):
    """Triggers the LangGraph multi-agent pipeline (Generate -> Review -> Schedule Advice -> Slack HITL)."""
    try:
        result = await content_service.start_generation_pipeline(
            topic=req.topic,
            tone=req.tone,
            platforms=req.platforms
        )
        return {"success": True, "data": result}
    except Exception as e:
        logger.exception("Generation pipeline error")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/posts")
async def list_posts(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    post_status = models.PostStatus(status) if status in models.PostStatus.__members__ else None
    posts = crud.get_posts(db, skip=skip, limit=limit, status=post_status)
    
    return {
        "count": len(posts),
        "posts": [
            {
                "id": p.id,
                "topic": p.topic,
                "tone": p.tone,
                "status": p.status.value,
                "target_platforms": p.target_platforms,
                "platform_contents": p.platform_contents,
                "review_score": p.review_score,
                "review_feedback": p.review_feedback,
                "scheduled_time": p.scheduled_time.isoformat() if p.scheduled_time else None,
                "published_at": p.published_at.isoformat() if p.published_at else None,
                "created_at": p.created_at.isoformat() if p.created_at else None,
                "updated_at": p.updated_at.isoformat() if p.updated_at else None
            }
            for p in posts
        ]
    }

@app.get("/api/posts/{post_id}")
async def get_post(post_id: int, db: Session = Depends(get_db)):
    post = crud.get_post_by_id(db, post_id)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    return {
        "id": post.id,
        "topic": post.topic,
        "tone": post.tone,
        "status": post.status.value,
        "target_platforms": post.target_platforms,
        "platform_contents": post.platform_contents,
        "review_score": post.review_score,
        "review_feedback": post.review_feedback,
        "review_passed": post.review_passed,
        "scheduled_time": post.scheduled_time.isoformat() if post.scheduled_time else None,
        "published_at": post.published_at.isoformat() if post.published_at else None,
        "created_at": post.created_at.isoformat() if post.created_at else None,
        "approvals": [
            {
                "id": a.id,
                "status": a.status,
                "reviewer": a.reviewer,
                "feedback": a.feedback,
                "responded_at": a.responded_at.isoformat() if a.responded_at else None
            }
            for a in post.approvals
        ],
        "publish_logs": [
            {
                "id": l.id,
                "platform": l.platform.value,
                "status": l.status,
                "external_post_id": l.external_post_id,
                "response_payload": l.response_payload,
                "error_message": l.error_message,
                "published_at": l.published_at.isoformat() if l.published_at else None
            }
            for l in post.publish_logs
        ]
    }

@app.put("/api/posts/{post_id}")
async def update_post(post_id: int, req: UpdatePostRequest, db: Session = Depends(get_db)):
    update_data = req.model_dump(exclude_unset=True)
    post = crud.update_post(db, post_id, **update_data)
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    return {"success": True, "post_id": post.id}

@app.delete("/api/posts/{post_id}")
async def delete_post(post_id: int, db: Session = Depends(get_db)):
    success = crud.delete_post(db, post_id)
    if not success:
        raise HTTPException(status_code=404, detail="Post not found")
    return {"success": True, "deleted_post_id": post_id}

@app.post("/api/posts/{post_id}/decision")
async def submit_human_decision(post_id: int, req: PostDecisionRequest):
    """Processes Human-in-the-Loop decision (Approve & Schedule / Publish Now / Reject)."""
    result = await content_service.handle_human_decision(
        post_id=post_id,
        action=req.action,
        reviewer=req.reviewer,
        feedback=req.feedback,
        custom_scheduled_time=req.custom_scheduled_time
    )
    if not result.get("success"):
        raise HTTPException(status_code=400, detail=result.get("error", "Decision processing failed"))
    return result

@app.post("/api/posts/{post_id}/publish")
async def force_publish_post(post_id: int):
    """Directly triggers the publishing service for an approved post."""
    result = await publishing_service.publish_post_now(post_id)
    if not result.get("success") and "not found" in result.get("error", ""):
        raise HTTPException(status_code=404, detail=result.get("error"))
    return result

# --- Slack Sandbox & Webhooks ---

@app.get("/api/slack/messages")
async def get_slack_mock_messages():
    """Returns mock Slack messages for the interactive in-dashboard emulator."""
    return {"messages": slack_notifier.get_mock_messages()}

@app.post("/api/slack/actions")
async def slack_interactive_actions(request: Request):
    """Handles interactive payload callbacks from Slack Block Kit buttons with signature verification."""
    try:
        body = await request.body()
        content_type = request.headers.get("content-type", "")

        # Verify Slack Request Signature
        timestamp = request.headers.get("X-Slack-Request-Timestamp")
        signature = request.headers.get("X-Slack-Signature")

        if not slack_notifier.verify_slack_signature(body, timestamp, signature):
            logger.warning("Rejected Slack action request due to invalid HMAC signature.")
            return JSONResponse({"status": "error", "message": "Invalid Slack request signature"}, status_code=status.HTTP_403_FORBIDDEN)
        
        if "application/x-www-form-urlencoded" in content_type:
            form = await request.form()
            payload = json.loads(form.get("payload", "{}"))
        else:
            payload = await request.json()

        actions = payload.get("actions", [])
        if not actions:
            return JSONResponse({"status": "no_action"})

        first_action = actions[0]
        action_id = first_action.get("action_id")
        post_id_val = int(first_action.get("value", 0))
        user_name = payload.get("user", {}).get("username", "Slack User")
        trigger_id = payload.get("trigger_id", f"trig_{post_id_val}_{action_id}")

        # Anti-replay deduplication check
        if trigger_id in slack_notifier._processed_action_triggers:
            logger.info(f"Duplicate Slack action trigger {trigger_id} received. Ignoring.")
            return JSONResponse({"status": "already_processed", "message": "Action has already been handled."})
        slack_notifier._processed_action_triggers.add(trigger_id)

        decision_map = {
            "approve_schedule_post": "approve_schedule",
            "publish_now_post": "publish_now",
            "reject_post": "reject"
        }
        action_decision = decision_map.get(action_id, "approve_schedule")

        res = await content_service.handle_human_decision(
            post_id=post_id_val,
            action=action_decision,
            reviewer=f"Slack @{user_name}"
        )

        return JSONResponse({"status": "handled", "decision": res})
    except Exception as e:
        logger.error(f"Error handling Slack action: {e}")
        return JSONResponse({"status": "error", "message": "Failed to process Slack action"}, status_code=400)

# --- Social Accounts & OAuth 2.0 ---

@app.get("/api/accounts")
async def list_social_accounts(db: Session = Depends(get_db)):
    accounts = crud.get_social_accounts(db)
    return {
        "accounts": [
            {
                "id": a.id,
                "platform": a.platform.value,
                "account_name": a.account_name,
                "account_id": a.account_id,
                "is_active": a.is_active,
                "has_token": bool(a.encrypted_access_token)
            }
            for a in accounts
        ]
    }

@app.post("/api/accounts/connect", status_code=status.HTTP_201_CREATED)
async def connect_account(req: ConnectAccountRequest, db: Session = Depends(get_db)):
    try:
        platform_enum = models.PlatformType(req.platform.upper())
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid platform '{req.platform}'")

    enc_access = token_security.encrypt(req.access_token) if req.access_token else None
    enc_refresh = token_security.encrypt(req.refresh_token) if req.refresh_token else None

    account = crud.upsert_social_account(
        db,
        platform=platform_enum,
        account_name=req.account_name,
        account_id=req.account_id,
        encrypted_access_token=enc_access,
        encrypted_refresh_token=enc_refresh,
        is_active=True
    )
    return {"success": True, "account_id": account.id, "platform": account.platform.value}

@app.get("/api/accounts/oauth/url")
async def get_oauth_url(platform: str, redirect_uri: str = "http://localhost:8000/api/accounts/oauth/callback"):
    """Generates OAuth 2.0 authorization URL with secure state and PKCE."""
    try:
        url = oauth_manager.get_authorization_url(platform, redirect_uri)
        return {"oauth_url": url, "platform": platform.upper()}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/accounts/oauth/callback")
async def handle_oauth_callback(
    code: str = Query(...),
    state: str = Query(...),
    platform: Optional[str] = Query(None),
    redirect_uri: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Handles OAuth 2.0 authorization code exchange and account connection."""
    try:
        exchange_result = await oauth_manager.exchange_code(
            platform=platform or "TWITTER",
            code=code,
            state=state,
            redirect_uri=redirect_uri
        )

        if exchange_result.get("success"):
            platform_key = exchange_result.get("platform", "TWITTER")
            platform_enum = models.PlatformType(platform_key)

            account = crud.upsert_social_account(
                db,
                platform=platform_enum,
                account_name=exchange_result.get("account_name", f"{platform_key} Account"),
                account_id=exchange_result.get("account_id"),
                encrypted_access_token=exchange_result.get("encrypted_access_token"),
                encrypted_refresh_token=exchange_result.get("encrypted_refresh_token"),
                is_active=True
            )
            return {
                "success": True,
                "message": f"Successfully connected {platform_key} account: {account.account_name}",
                "account": {
                    "id": account.id,
                    "platform": account.platform.value,
                    "account_name": account.account_name,
                    "is_active": account.is_active
                }
            }
        else:
            raise HTTPException(status_code=400, detail="OAuth code exchange failed")
    except Exception as e:
        logger.error(f"OAuth callback error: {e}")
        raise HTTPException(status_code=400, detail=f"OAuth authorization failed: {str(e)}")

# --- Analytics & Statistics ---

@app.get("/api/stats")
async def get_dashboard_stats(db: Session = Depends(get_db)):
    all_posts = db.query(models.Post).all()
    
    total_generated = len(all_posts)
    pending_approval = sum(1 for p in all_posts if p.status == models.PostStatus.PENDING_APPROVAL)
    scheduled = sum(1 for p in all_posts if p.status == models.PostStatus.SCHEDULED)
    published = sum(1 for p in all_posts if p.status == models.PostStatus.PUBLISHED)
    rejected = sum(1 for p in all_posts if p.status == models.PostStatus.REJECTED)
    
    scores = [p.review_score for p in all_posts if p.review_score is not None and p.review_score > 0]
    avg_score = round(sum(scores) / len(scores), 1) if scores else 0.0

    platform_dist = {"TWITTER": 0, "LINKEDIN": 0, "META_FACEBOOK": 0, "META_INSTAGRAM": 0}
    for p in all_posts:
        for plt in (p.target_platforms or []):
            if plt in platform_dist:
                platform_dist[plt] += 1

    return {
        "total_generated": total_generated,
        "pending_approval": pending_approval,
        "scheduled": scheduled,
        "published": published,
        "rejected": rejected,
        "average_quality_score": avg_score,
        "platform_distribution": platform_dist
    }

@app.get("/api/analytics")
async def get_detailed_analytics(db: Session = Depends(get_db)):
    """Provides analytics metrics across published posts, quality trends, and platform distribution."""
    posts = db.query(models.Post).all()
    logs = db.query(models.PublishLog).all()

    total_publications = len(logs)
    successful_publications = sum(1 for l in logs if l.status in ("SUCCESS", "SIMULATED"))
    failed_publications = sum(1 for l in logs if l.status == "FAILED")
    success_rate = round((successful_publications / total_publications * 100), 1) if total_publications > 0 else 100.0

    platform_breakdown = {}
    for l in logs:
        p_name = l.platform.value if hasattr(l.platform, "value") else str(l.platform)
        if p_name not in platform_breakdown:
            platform_breakdown[p_name] = {"success": 0, "failed": 0}
        if l.status in ("SUCCESS", "SIMULATED"):
            platform_breakdown[p_name]["success"] += 1
        else:
            platform_breakdown[p_name]["failed"] += 1

    return {
        "summary": {
            "total_posts": len(posts),
            "total_publications": total_publications,
            "success_rate_percent": success_rate,
            "failed_publications": failed_publications
        },
        "platform_performance": platform_breakdown,
        "live_engagement": {
            "status": "unavailable_requires_live_oauth_connection",
            "metrics": {
                "impressions": None,
                "likes": None,
                "shares": None
            }
        }
    }

# --- Optional AI Image Generation ---

@app.post("/api/images/generate")
async def generate_post_image(req: ImageGenerateRequest):
    """Optional AI image generation assistant endpoint."""
    res = await image_service.generate_image_for_post(topic=req.topic, style_prompt=req.style_prompt)
    return res

# --- Mount Static Frontend ---
frontend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "frontend"))
if os.path.exists(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

@app.get("/")
async def serve_index():
    index_path = os.path.join(frontend_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "AI Social Media Agent Backend is Live! Visit /docs for API documentation."}

