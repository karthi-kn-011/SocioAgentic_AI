"""initial_schema

Revision ID: 001_initial_schema
Revises: 
Create Date: 2026-09-22 18:00:00.000000

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = '001_initial_schema'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    existing_tables = inspector.get_table_names()

    # 1. posts table
    if 'posts' not in existing_tables:
        op.create_table(
            'posts',
            sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
            sa.Column('topic', sa.String(length=255), nullable=False),
            sa.Column('tone', sa.String(length=100), server_default='Professional & Engaging', nullable=True),
            sa.Column('raw_content', sa.Text(), nullable=True),
            sa.Column('platform_contents', sa.JSON(), nullable=True),
            sa.Column('target_platforms', sa.JSON(), nullable=True),
            sa.Column('status', sa.Enum('DRAFT', 'REVIEWING', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'SCHEDULED', 'PUBLISHING', 'PUBLISHED', 'FAILED', name='poststatus'), server_default='DRAFT', nullable=True),
            sa.Column('review_score', sa.Integer(), server_default='0', nullable=True),
            sa.Column('review_feedback', sa.Text(), nullable=True),
            sa.Column('review_passed', sa.Boolean(), server_default='0', nullable=True),
            sa.Column('scheduled_time', sa.DateTime(), nullable=True),
            sa.Column('published_at', sa.DateTime(), nullable=True),
            sa.Column('thread_id', sa.String(length=100), nullable=True),
            sa.Column('created_at', sa.DateTime(), nullable=True),
            sa.Column('updated_at', sa.DateTime(), nullable=True)
        )
        op.create_index(op.f('ix_posts_id'), 'posts', ['id'], unique=False)
        op.create_index(op.f('ix_posts_status'), 'posts', ['status'], unique=False)
        op.create_index(op.f('ix_posts_scheduled_time'), 'posts', ['scheduled_time'], unique=False)
        op.create_index(op.f('ix_posts_thread_id'), 'posts', ['thread_id'], unique=False)

    # 2. approval_requests table
    if 'approval_requests' not in existing_tables:
        op.create_table(
            'approval_requests',
            sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
            sa.Column('post_id', sa.Integer(), sa.ForeignKey('posts.id', ondelete='CASCADE'), nullable=False),
            sa.Column('slack_channel', sa.String(length=100), nullable=True),
            sa.Column('slack_message_ts', sa.String(length=100), nullable=True),
            sa.Column('status', sa.String(length=50), server_default='PENDING', nullable=True),
            sa.Column('reviewer', sa.String(length=100), nullable=True),
            sa.Column('feedback', sa.Text(), nullable=True),
            sa.Column('responded_at', sa.DateTime(), nullable=True),
            sa.Column('created_at', sa.DateTime(), nullable=True)
        )
        op.create_index(op.f('ix_approval_requests_id'), 'approval_requests', ['id'], unique=False)

    # 3. social_accounts table
    if 'social_accounts' not in existing_tables:
        op.create_table(
            'social_accounts',
            sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
            sa.Column('platform', sa.Enum('TWITTER', 'LINKEDIN', 'META_FACEBOOK', 'META_INSTAGRAM', name='platformtype'), nullable=False),
            sa.Column('account_name', sa.String(length=150), nullable=False),
            sa.Column('account_id', sa.String(length=150), nullable=True),
            sa.Column('encrypted_access_token', sa.Text(), nullable=True),
            sa.Column('encrypted_refresh_token', sa.Text(), nullable=True),
            sa.Column('token_expires_at', sa.DateTime(), nullable=True),
            sa.Column('is_active', sa.Boolean(), server_default='1', nullable=True),
            sa.Column('created_at', sa.DateTime(), nullable=True),
            sa.Column('updated_at', sa.DateTime(), nullable=True)
        )
        op.create_index(op.f('ix_social_accounts_id'), 'social_accounts', ['id'], unique=False)

    # 4. publish_logs table
    if 'publish_logs' not in existing_tables:
        op.create_table(
            'publish_logs',
            sa.Column('id', sa.Integer(), nullable=False, primary_key=True),
            sa.Column('post_id', sa.Integer(), sa.ForeignKey('posts.id', ondelete='CASCADE'), nullable=False),
            sa.Column('platform', sa.Enum('TWITTER', 'LINKEDIN', 'META_FACEBOOK', 'META_INSTAGRAM', name='platformtype'), nullable=False),
            sa.Column('status', sa.String(length=50), nullable=False),
            sa.Column('response_payload', sa.JSON(), nullable=True),
            sa.Column('error_message', sa.Text(), nullable=True),
            sa.Column('external_post_id', sa.String(length=255), nullable=True),
            sa.Column('published_at', sa.DateTime(), nullable=True)
        )
        op.create_index(op.f('ix_publish_logs_id'), 'publish_logs', ['id'], unique=False)


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    existing_tables = inspector.get_table_names()

    if 'publish_logs' in existing_tables:
        op.drop_table('publish_logs')
    if 'social_accounts' in existing_tables:
        op.drop_table('social_accounts')
    if 'approval_requests' in existing_tables:
        op.drop_table('approval_requests')
    if 'posts' in existing_tables:
        op.drop_table('posts')

