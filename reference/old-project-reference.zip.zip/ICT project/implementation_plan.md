# AI Social Media Agent — Master Implementation Plan

An end-to-end autonomous multi-agent social media management system powered by **LangGraph**, **FastAPI**, **Slack Human-in-the-Loop (HITL)** interactive approval, **APScheduler**, and multi-platform connectors (**X / Twitter**, **LinkedIn**, and **Meta Graph API**) with a sleek modern web dashboard.

---

## 🏗️ System Architecture & Workflow

```mermaid
flowchart TD
    User([User / Content Creator]) -->|Input Topic & Persona| UI[Modern Web Dashboard]
    UI -->|API Request| API[FastAPI Backend]
    
    subgraph LangGraph_Workflow [LangGraph Multi-Agent Workflow]
        direction TB
        NodeGen[1. Content Generation Agent\nLLM Prompting & Multi-Variant] --> NodeReview[2. AI Review & Quality Agent\nPolicy, tone, hashtag & length check]
        NodeReview -->|Pass| NodeSaveDraft[3. Draft State & Database Persistence]
        NodeReview -->|Needs Revision| NodeGen
        NodeSaveDraft --> NodeSlack[4. Human-in-the-Loop Node\nDispatch Slack Interactive Message]
    end

    API --> LangGraph_Workflow
    
    NodeSlack -->|Slack Webhook / Bolt| SlackWorkspace[Slack Channel]
    SlackWorkspace -->|Interactive Buttons: Approve / Reject / Edit| SlackAction[Slack Interaction Handler]
    
    SlackAction -->|Reject / Edit Feedback| NodeGen
    SlackAction -->|Approved| Scheduler[APScheduler / Cron Engine]
    
    Scheduler -->|Trigger on Time| Publisher[Publishing Dispatcher]
    
    subgraph Integrations [Social Media APIs / OAuth 2.0]
        Publisher --> XAPI[X / Twitter API v2]
        Publisher --> LinkedInAPI[LinkedIn Share API]
        Publisher --> MetaAPI[Meta Graph API / Facebook / Instagram]
    end
    
    Integrations -->|Log Result & Analytics| DB[(SQLite / PostgreSQL)]
    DB -->|Real-time Status Updates| UI
```

---

## 📦 Project Structure

```
c:\Users\Lenovo\OneDrive\Documents\ICT project\
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py                     # FastAPI entry point & routers
│   │   ├── config.py                   # Environment & settings via pydantic-settings
│   │   ├── agents/
│   │   │   ├── __init__.py
│   │   │   ├── content_agent.py        # LLM prompt orchestration & variant generation
│   │   │   ├── review_agent.py         # Tone, safety, guidelines, hashtag analyzer
│   │   │   └── scheduler_agent.py     # Optimal posting time analyzer
│   │   ├── graph/
│   │   │   ├── __init__.py
│   │   │   ├── state.py                # LangGraph TypedDict state definitions
│   │   │   ├── nodes.py                # Agent execution nodes
│   │   │   └── workflow.py             # Compiled LangGraph state graph with interrupt/resume
│   │   ├── integrations/
│   │   │   ├── __init__.py
│   │   │   ├── slack.py                # Slack Bolt / Interactive block kit messenger
│   │   │   ├── x_api.py                # Twitter/X API v2 client
│   │   │   ├── linkedin_api.py         # LinkedIn UGC / Share API client
│   │   │   ├── meta_api.py             # Facebook & Instagram Graph API client
│   │   │   └── mock_publisher.py       # Sandbox/Mock mode for testing without active live keys
│   │   ├── auth/
│   │   │   ├── __init__.py
│   │   │   ├── oauth.py                # Multi-platform OAuth 2.0 token manager
│   │   │   └── security.py             # Encryption for access tokens at rest
│   │   ├── scheduler/
│   │   │   ├── __init__.py
│   │   │   └── scheduler.py            # APScheduler BackgroundScheduler setup & tasks
│   │   ├── database/
│   │   │   ├── __init__.py
│   │   │   ├── database.py             # SQLAlchemy async/sync session & engine
│   │   │   ├── models.py               # Post, Account, Log, ApprovalTask models
│   │   │   └── crud.py                 # DB queries & operations
│   │   └── services/
│   │       ├── __init__.py
│   │       ├── content_service.py      # Workflow invocation service
│   │       └── publishing_service.py   # Scheduling & dispatch service
├── frontend/
│   ├── index.html                      # Single page application with clean tabs
│   ├── css/
│   │   └── styles.css                  # Dark mode, glassmorphism, responsive styles
│   └── js/
│       ├── app.js                      # Core reactive state & API connector
│       ├── dashboard.js                # Stats, charts, recent activities
│       ├── generator.js                # AI Prompt generation & review panel
│       ├── approval.js                 # In-app HITL approval + Slack emulator
│       ├── calendar.js                 # Scheduled posts calendar view
│       └── accounts.js                 # Social account connection & OAuth manager
├── tests/
│   ├── test_agents.py                  # Agent unit tests (generation & review)
│   ├── test_workflow.py                # LangGraph state machine test
│   ├── test_slack.py                   # Slack payload & webhook tests
│   ├── test_publishing.py              # Scheduler & publishing tests
│   └── conftest.py
├── .env.example
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── README.md
└── .gitignore
```

---

## 🚀 Phased Implementation Roadmap

### Phase 1: Project Foundation & Core Environment
- Initialize `requirements.txt` with `fastapi`, `uvicorn`, `langgraph`, `langchain`, `pydantic`, `sqlalchemy`, `apscheduler`, `slack-bolt`, `httpx`, `python-dotenv`, `pytest`, `cryptography`.
- Configure SQLite database with SQLAlchemy (`Post`, `SocialAccount`, `PublishLog`, `ApprovalRequest`).
- Create environment configuration structure (`.env.example` & `config.py`) with support for sandbox/mock modes so it runs out-of-the-box even before external credentials are plugged in.

### Phase 2: AI Content & Review Agents
- **Content Agent**: Generates platform-tailored drafts (X: 280 chars + hashtags; LinkedIn: professional storytelling + formatting; Meta: visual-first captions).
- **Review Agent**: Autonomous quality checker analyzing brand voice, length limits, forbidden keywords, hashtags, and virality score.
- **Provider Flexibility**: Supports OpenAI, Anthropic, Google Gemini (via LangChain), and local fallback mock generator.

### Phase 3: LangGraph Multi-Agent Workflow with State Persistence
- Define `AgentState` (`topic`, `variants`, `review_notes`, `approved`, `scheduled_at`, `platforms`, `status`, `thread_id`).
- Construct cyclic LangGraph: `generate` -> `review` -> `check_quality` (loop if low score) -> `save_draft` -> `request_approval`.
- Support interrupt / resume capability when human intervention happens.

### Phase 4: Slack Human-in-the-Loop (HITL) Integration
- Build Slack Block Kit message generator displaying post preview, platform tags, quality score, and action buttons (`[ Approve ]`, `[ Reject ]`, `[ Edit / Regenerate ]`).
- Implement Slack webhook/action receiver endpoint (`/api/slack/events` & `/api/slack/actions`) in FastAPI.
- Include an in-app **Slack Simulation Sandbox** in the frontend dashboard to test and demonstrate full interactive approvals without requiring live bot tokens.

### Phase 5: Scheduling Engine (APScheduler)
- Integrate `AsyncIOScheduler` / `BackgroundScheduler` to poll pending approved posts.
- Support immediate publishing, optimal time scheduling, and manual calendar slot picking.
- Handle resilient execution, retry logic, and status updates on completion or failure.

### Phase 6: Social Media Platform Connectors & OAuth 2.0
- Connectors for:
  - **X (Twitter) API v2**: `POST /2/tweets`
  - **LinkedIn API**: `POST /v2/ugcPosts`
  - **Meta Graph API**: `POST /{page-id}/feed` & Instagram Content Publishing API
  - **Mock / Sandbox Publisher**: Simulates network latency, response payloads, and platform verification IDs.
- Secure token storage with symmetric Fernet encryption for OAuth refresh/access tokens.

### Phase 7: Web Dashboard UI
- State-of-the-art responsive UI (Dark mode / Glassmorphism):
  - **Analytics Overview**: Published vs pending posts, platform distribution metrics, engagement estimates.
  - **Agent Generator Studio**: Live generation playground with tone/persona selectors, multi-platform preview cards.
  - **HITL Approval Queue**: Live interactive approval console mirroring Slack actions.
  - **Publishing Calendar**: Visual weekly/monthly schedule matrix.
  - **Accounts & Integrations Hub**: API keys, webhook test tool, OAuth connection toggles.

### Phase 8: Testing & Verification
- Unit and integration tests covering:
  - Agent output correctness and review gating.
  - LangGraph state transitions and interrupt/resume.
  - Slack interaction payloads and state updates.
  - APScheduler job registration and execution.
  - API publishing handlers.

---

## 🔍 Verification Plan

### Automated Tests
```powershell
pytest tests/ -v
```

### Manual Verification & Demo Walkthrough
1. **Agent Pipeline Run**: Trigger generation via UI/API, inspect generated draft and AI review scores.
2. **Slack HITL Approval**: Trigger Slack card, click "Approve" (or simulate in UI), verify status transitions from `PENDING_APPROVAL` to `APPROVED` / `SCHEDULED`.
3. **Scheduler & Publisher**: Set a scheduled time 10 seconds in future; verify APScheduler fires, triggers publisher, and records `PUBLISHED` status in database.
4. **Dashboard Experience**: Test UI across Generator, Approvals, Calendar, and Integration tabs.
