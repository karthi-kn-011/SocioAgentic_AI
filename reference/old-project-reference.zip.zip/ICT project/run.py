import sys
import os

# Ensure UTF-8 output on Windows console
if sys.platform == "win32":
    os.environ["PYTHONIOENCODING"] = "utf-8"

import uvicorn
from backend.app.config import settings

if __name__ == "__main__":
    print("=" * 65)
    print(f"  Starting {settings.APP_NAME}")
    print(f"  Web Dashboard: http://localhost:{settings.PORT}")
    print(f"  API Documentation: http://localhost:{settings.PORT}/docs")
    print("  LangGraph & APScheduler Engine Active")
    print("=" * 65)
    uvicorn.run(
        "backend.app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=False
    )
